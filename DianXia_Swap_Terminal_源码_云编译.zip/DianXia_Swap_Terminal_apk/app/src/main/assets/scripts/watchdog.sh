#!/system/bin/sh
# 交换终端 · 系统级作业守护（真正执行脚本的进程）
# 由 service.sh / boot-completed.sh 在开机时拉起，父进程是 ksud / init。
# 它不属于 KernelSU 管理器 App 的进程树：划掉后台、force-stop 管理器都不会波及它。
#
# 工作方式：WebUI 只往 jobs/ 里投递任务描述，守护扫到 ready 标记后 fork runner.sh 执行。
# 卡密通过 FIFO（内核管道缓冲）传递，不写入磁盘文件。

ROOT=/data/local/tmp/DianXia_Swap_Terminal
JOBS="$ROOT/jobs"
PIDFILE="$ROOT/daemon.pid"
HEARTBEAT="$ROOT/daemon.alive"
VERSION="$ROOT/daemon.version"
DAEMON_VER=2

mkdir -p "$JOBS"
chmod 700 "$ROOT" "$JOBS" 2>/dev/null

# ---- 单实例 / 版本升级 ----
# 模块升级后旧版守护（只降 oom、不认领任务）必须被顶掉，否则会一直占着 pid 文件
if [ -f "$PIDFILE" ]; then
    old=$(cat "$PIDFILE" 2>/dev/null)
    ver=$(cat "$VERSION" 2>/dev/null)
    if [ -n "$old" ] && [ "$old" != "$$" ] && [ -d "/proc/$old" ]; then
        if grep -q 'watchdog.sh' "/proc/$old/cmdline" 2>/dev/null; then
            if [ "$ver" = "$DAEMON_VER" ]; then
                exit 0
            fi
            kill -9 "$old" 2>/dev/null
        fi
    fi
fi
printf '%s' "$$" > "$PIDFILE"
printf '%s' "$DAEMON_VER" > "$VERSION"

# ---- 尽量别被 LMK 回收 ----
echo -900 > "/proc/$$/oom_score_adj" 2>/dev/null
echo -900 > "/proc/$$/oom_adj" 2>/dev/null

# 父进程退出 / 终端挂断时不要跟着死
trap '' HUP INT TERM PIPE 2>/dev/null

printf '%s' "$(date +%s)" > "$HEARTBEAT"

while true; do
    # 心跳：WebUI 据此判断守护是否在线
    printf '%s' "$(date +%s)" > "$HEARTBEAT" 2>/dev/null

    # ---- 认领新任务 ----
    for ready in "$JOBS"/*/ready; do
        [ -f "$ready" ] || continue
        J=${ready%/ready}
        [ -d "$J" ] || continue
        [ -f "$J/claimed" ] && continue
        [ -f "$J/done" ] && continue

        # mv 是原子的，保证只有一个守护实例认领
        if mv "$ready" "$J/claimed" 2>/dev/null; then
            (
                echo -900 > "/proc/$$/oom_score_adj" 2>/dev/null
                echo -900 > "/proc/$$/oom_adj" 2>/dev/null
                trap '' HUP INT TERM PIPE 2>/dev/null
                sh "$ROOT/runner.sh" "$J" > "$J/out" 2>&1 < /dev/null
                printf '%s' "$?" > "$J/done"
                # FIFO / meta 用完即删，目录里只留 out + done 供回看
                rm -f "$J/in" "$J/meta" "$J/ready" 2>/dev/null
            ) &
        fi
    done

    # ---- 清理 24 小时前已结束的作业，以及 .rc 转译出来的临时脚本 ----
    for d in "$JOBS"/*; do
        [ -d "$d" ] || continue
        [ -f "$d/done" ] || continue
        find "$d" -maxdepth 0 -mmin +1440 -exec rm -rf "$d" \; 2>/dev/null
    done
    [ -d "$ROOT/translated" ] && \
        find "$ROOT/translated" -type f -mmin +1440 -exec rm -f {} \; 2>/dev/null

    sleep 1
done

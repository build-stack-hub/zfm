#!/system/bin/sh
# 交换终端 · 示例脚本：模块与挂载检查（只读）
echo "== 已安装模块 =="
if [ -d /data/adb/modules ]; then
    for d in /data/adb/modules/*; do
        [ -d "$d" ] || continue
        n=$(grep -m1 '^name=' "$d/module.prop" 2>/dev/null | cut -d= -f2-)
        [ -z "$n" ] && n="(unknown)"
        [ -f "$d/disable" ] && s="已禁用" || s="已启用"
        printf '  • %-24s %s\n' "$n" "$s"
    done
else
    echo "  未找到模块目录"
fi
echo
echo "== 模块挂载点 =="
grep -E 'KSU|modules' /proc/mounts 2>/dev/null | head -n 12 || echo "  无相关信息"

#!/system/bin/sh
# 交换终端 · 示例脚本：卡密输入演示（只读，不验证卡密）
# 用于测试 WebUI 的「脚本输入 / 卡密」功能

printf "请输入卡密: "
read -r CARD_KEY
printf "请再次确认 (y/n): "
read -r CONFIRM

echo "--------------------------------"
echo "方式 1 · stdin read   : 卡密长度 ${#CARD_KEY} 位，确认=$CONFIRM"
echo "方式 2 · 位置参数 \$1  : 卡密长度 ${#1} 位"
echo "方式 3 · 环境变量     : KSU_CARD_KEY 长度 ${#KSU_CARD_KEY} 位"
echo "                        KSU_INPUT_1  长度 ${#KSU_INPUT_1} 位"
echo "--------------------------------"
echo "✓ 三种通道都拿到输入了（内容不回显，仅显示长度）"

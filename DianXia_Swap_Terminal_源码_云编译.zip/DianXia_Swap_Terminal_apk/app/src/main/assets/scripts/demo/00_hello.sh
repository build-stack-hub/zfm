#!/system/bin/sh
# 交换终端 · 示例脚本：环境探测（只读）
echo "======================================"
echo " DianXia_Swap_Terminal / 交换终端"
echo "======================================"
echo "时间    : $(date '+%Y-%m-%d %H:%M:%S')"
echo "用户    : $(id -un) (uid=$(id -u))"
echo "内核    : $(uname -r)"
echo "设备    : $(getprop ro.product.model 2>/dev/null)"
echo "Android : $(getprop ro.build.version.release 2>/dev/null)"
echo "Shell   : $0"
echo "======================================"
echo "Hello from KSU WebUI 👋"

#!/system/bin/sh
# 交换终端 · 示例脚本：设备信息摘要（只读）
printf '%-16s %s\n' "型号" "$(getprop ro.product.model)"
printf '%-16s %s\n' "厂商" "$(getprop ro.product.manufacturer)"
printf '%-16s %s\n' "Android" "$(getprop ro.build.version.release) (API $(getprop ro.build.version.sdk))"
printf '%-16s %s\n' "内核" "$(uname -r)"
printf '%-16s %s\n' "架构" "$(getprop ro.product.cpu.abi)"
printf '%-16s %s\n' "KernelSU" "$(ksud -V 2>/dev/null || echo '未检测到 ksud')"
printf '%-16s %s\n' "运行时间" "$(uptime)"
echo "---- 存储 ----"
df -h /data /sdcard 2>/dev/null
echo "---- 内存 ----"
free -h 2>/dev/null || cat /proc/meminfo | head -n 3

#!/system/bin/sh
# 交换终端 · 作业执行器（只由 watchdog.sh 调用）
# 用法: runner.sh <job_dir>
#   job_dir/meta   : SCRIPT_B64=<脚本路径的 base64> 与 N=<输入行数>，不含卡密
#   job_dir/in     : FIFO，WebUI 写入的卡密经内核管道缓冲传入，不落盘
#   job_dir/out    : 由 watchdog 重定向，脚本 stdout/stderr 都进这里

J="$1"
[ -d "$J" ] || exit 1
[ -f "$J/meta" ] || { printf '%s' '127' > "$J/done"; exit 127; }

printf '%s' "$$" > "$J/pid" 2>/dev/null
echo -900 > "/proc/$$/oom_score_adj" 2>/dev/null
echo -900 > "/proc/$$/oom_adj" 2>/dev/null
trap '' HUP INT TERM PIPE 2>/dev/null

# 解析任务描述（base64 避免路径里的空格/引号问题）
SCRIPT_B64=$(sed -n 's/^SCRIPT_B64=//p' "$J/meta" 2>/dev/null | head -n 1)
N=$(sed -n 's/^N=//p' "$J/meta" 2>/dev/null | head -n 1)
case "$N" in ''|*[!0-9]*) N=0 ;; esac
SCRIPT=$(printf '%s' "$SCRIPT_B64" | base64 -d 2>/dev/null)
[ -f "$SCRIPT" ] || { printf '%s' '127' > "$J/done"; exit 127; }

# ---- 从 FIFO 读输入（最多 8 行），只存在内存里 ----
V1=''; V2=''; V3=''; V4=''; V5=''; V6=''; V7=''; V8=''
if [ "$N" -gt 0 ] && [ -p "$J/in" ]; then
    exec 3< "$J/in"
    IFS= read -r V1 <&3 || V1=''
    IFS= read -r V2 <&3 || V2=''
    IFS= read -r V3 <&3 || V3=''
    IFS= read -r V4 <&3 || V4=''
    IFS= read -r V5 <&3 || V5=''
    IFS= read -r V6 <&3 || V6=''
    IFS= read -r V7 <&3 || V7=''
    IFS= read -r V8 <&3 || V8=''
    exec 3<&-
fi

# ---- 位置参数 $1..$N ----
set --
i=0
for v in "$V1" "$V2" "$V3" "$V4" "$V5" "$V6" "$V7" "$V8"; do
    i=$((i + 1))
    [ "$i" -le "$N" ] && set -- "$@" "$v"
done

# ---- 执行：stdin 由花括号组生成（不落盘），同时注入环境变量 ----
{
    i=0
    for v in "$V1" "$V2" "$V3" "$V4" "$V5" "$V6" "$V7" "$V8"; do
        i=$((i + 1))
        [ "$i" -le "$N" ] && printf '%s\n' "$v"
    done
} | env \
    KSU_INPUT_1="$V1" KSU_INPUT_2="$V2" KSU_INPUT_3="$V3" KSU_INPUT_4="$V4" \
    KSU_INPUT_5="$V5" KSU_INPUT_6="$V6" KSU_INPUT_7="$V7" KSU_INPUT_8="$V8" \
    KSU_CARD_KEY="$V1" KSU_KEY="$V1" CARD_KEY="$V1" \
    sh "$SCRIPT" "$@"

exit $?

/* 交换终端 · DianXia_Swap_Terminal — WebUI logic
   兼容: kernelsu ESM API / ksu.exec 回调 / ksu.exec 同步 / 浏览器预览模式
   安全: 所有外部文本一律用 textContent，路径一律经 shell 引号转义 */
(function () {
  'use strict';

  var $ = function (s) { return document.querySelector(s); };
  var DEFAULT_DIR = '/data/local/tmp/DianXia_Swap_Terminal/scripts';
  var CANDIDATE_DIRS = [
    DEFAULT_DIR,
    '/data/local/tmp/scripts',
    '/sdcard/Download/scripts',
    '/sdcard/Download',
    '/sdcard/Documents'
  ];
  var params = new URLSearchParams(location.search);
  var FORCE_DEMO = params.has('demo');
  var DEMO_SCENE = params.get('demo') || '';

  var FILE_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h8l4 4v14H6z"></path><path d="M14 3v5h4"></path><path d="M9 13l2 2-2 2M13 17h3"></path></svg>';
  var ARROW_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h13"></path><path d="m13 6 6 6-6 6"></path></svg>';
  var EYE_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12s3.6-6 9.5-6 9.5 6 9.5 6-3.6 6-9.5 6-9.5-6-9.5-6z"></path><circle cx="12" cy="12" r="2.6"></circle></svg>';
  var DEL_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 7h14M9 7V5h6v2M7 7l1 13h8l1-13"></path></svg>';

  var DEMO_SCRIPTS = [
    { name: '00_hello.sh', size: 428 },
    { name: '01_device_info.sh', size: 1260 },
    { name: '02_mount_check.sh', size: 876 },
    { name: '03_card_key_demo.sh', size: 742 },
    { name: '04_init_rc_demo.rc', size: 604, kind: 'rc' }
  ];
  var DEMO_CONTENT = {
    '00_hello.sh': '#!/system/bin/sh\n# 交换终端 · 示例脚本：环境探测（只读）\necho "======================================"\necho " DianXia_Swap_Terminal / 交换终端"\necho "======================================"\necho "时间    : $(date \'+%Y-%m-%d %H:%M:%S\')"\necho "用户    : $(id -un) (uid=$(id -u))"\necho "内核    : $(uname -r)"\necho "设备    : $(getprop ro.product.model)"\necho "Android : $(getprop ro.build.version.release)"\necho "======================================"\necho "Hello from KSU WebUI 👋"',
    '03_card_key_demo.sh': '#!/system/bin/sh\n# 交换终端 · 示例脚本：卡密输入演示（只读，不验证卡密）\n# 用于测试 WebUI 的「脚本输入 / 卡密」功能\n\nprintf "请输入卡密: "\nread -r CARD_KEY\nprintf "请再次确认 (y/n): "\nread -r CONFIRM\n\necho "--------------------------------"\necho "方式 1 · stdin read   : 卡密长度 ${#CARD_KEY} 位，确认=$CONFIRM"\necho "方式 2 · 位置参数 \\$1  : 卡密长度 ${#1} 位"\necho "方式 3 · 环境变量     : KSU_CARD_KEY 长度 ${#KSU_CARD_KEY} 位"\necho "✓ 三种通道都拿到输入了（内容不回显，仅显示长度）"',
    '04_init_rc_demo.rc': '# 交换终端 · init.rc 兼容演示（只读写 /data/local/tmp，不改系统属性）\n' +
      '# 这个文件是 Android init 语言，不是 shell；WebUI 会自动识别并转译后执行。\n\n' +
      'on boot\n' +
      '    write /data/local/tmp/DianXia_Swap_Terminal_demo.txt dianxia-rc-ok\n' +
      '    mkdir /data/local/tmp/DianXia_Swap_Terminal_demo_dir 0755\n' +
      '    exec -- echo "rc-exec-ok"\n' +
      '    symlink /data/local/tmp/DianXia_Swap_Terminal_demo.txt /data/local/tmp/DianXia_Swap_Terminal_demo_link\n\n' +
      '# service 段由 init 管理，转译时会跳过并给出提示\n' +
      'service demo_svc /system/bin/sh\n' +
      '    oneshot\n' +
      '    disabled',
    '01_device_info.sh': '#!/system/bin/sh\n# 交换终端 · 示例脚本：设备信息摘要（只读）\nprintf \'%-16s %s\\n\' "型号" "$(getprop ro.product.model)"\nprintf \'%-16s %s\\n\' "厂商" "$(getprop ro.product.manufacturer)"\nprintf \'%-16s %s\\n\' "Android" "$(getprop ro.build.version.release)"\nprintf \'%-16s %s\\n\' "内核" "$(uname -r)"\necho "---- 存储 ----"\ndf -h /data /sdcard 2>/dev/null\necho "---- 内存 ----"\nfree -h 2>/dev/null || head -n 3 /proc/meminfo',
    '02_mount_check.sh': '#!/system/bin/sh\n# 交换终端 · 示例脚本：模块与挂载检查（只读）\necho "== 已安装模块 =="\nfor d in /data/adb/modules/*; do\n    [ -d "$d" ] || continue\n    n=$(grep -m1 \'^name=\' "$d/module.prop" | cut -d= -f2-)\n    printf \'  • %-24s\\n\' "$n"\ndone\necho\necho "== 模块挂载点 =="\ngrep -E \'KSU|modules\' /proc/mounts | head -n 12'
  };
  var DEMO_OUTPUT = '======================================\n DianXia_Swap_Terminal / 交换终端\n======================================\n时间    : 2026-11-12 20:41:07\n用户    : root (uid=0)\n内核    : 5.10.198-android12-9-g4f0a1c2d\n设备    : Pixel 8 Pro\nAndroid : 14\nShell   : 00_hello.sh\n======================================\nHello from KSU WebUI 👋';

  /* ---------- 后台作业 ----------
     WebUI 里 exec/spawn 起的 shell 是「管理器 App 的子进程」，划掉最近任务会被一起回收。
     这里改为：提交后立刻返回 → setsid 新会话独立运行 → 输出写文件 → 页面轮询增量。
     卡密只走 stdin 管道，不写入任何文件。 */
  var JOB_ROOT = '/data/local/tmp/DianXia_Swap_Terminal';
  var JOBS_DIR = JOB_ROOT + '/jobs';
  var MODULE_DIR = '/data/local/tmp/DianXia_Swap_Terminal/apk';
  var RUNNER_PATH = JOB_ROOT + '/runner.sh';
  var RUNNER_B64 = 'IyEvc3lzdGVtL2Jpbi9zaAojIOS6pOaNoue7iOerryDCtyDkvZzkuJrmiafooYzlmajvvIjlj6rnlLEgd2F0Y2hkb2cuc2gg6LCD55So77yJCiMg55So5rOVOiBydW5uZXIuc2ggPGpvYl9kaXI+CiMgICBqb2JfZGlyL21ldGEgICA6IFNDUklQVF9CNjQ9POiEmuacrOi3r+W+hOeahCBiYXNlNjQ+IOS4jiBOPTzovpPlhaXooYzmlbA+77yM5LiN5ZCr5Y2h5a+GCiMgICBqb2JfZGlyL2luICAgICA6IEZJRk/vvIxXZWJVSSDlhpnlhaXnmoTljaHlr4bnu4/lhoXmoLjnrqHpgZPnvJPlhrLkvKDlhaXvvIzkuI3okL3nm5gKIyAgIGpvYl9kaXIvb3V0ICAgIDog55SxIHdhdGNoZG9nIOmHjeWumuWQke+8jOiEmuacrCBzdGRvdXQvc3RkZXJyIOmDvei/m+i/memHjAoKSj0iJDEiClsgLWQgIiRKIiBdIHx8IGV4aXQgMQpbIC1mICIkSi9tZXRhIiBdIHx8IHsgcHJpbnRmICclcycgJzEyNycgPiAiJEovZG9uZSI7IGV4aXQgMTI3OyB9CgpwcmludGYgJyVzJyAiJCQiID4gIiRKL3BpZCIgMj4vZGV2L251bGwKZWNobyAtOTAwID4gIi9wcm9jLyQkL29vbV9zY29yZV9hZGoiIDI+L2Rldi9udWxsCmVjaG8gLTkwMCA+ICIvcHJvYy8kJC9vb21fYWRqIiAyPi9kZXYvbnVsbAp0cmFwICcnIEhVUCBJTlQgVEVSTSBQSVBFIDI+L2Rldi9udWxsCgojIOino+aekOS7u+WKoeaPj+i/sO+8iGJhc2U2NCDpgb/lhY3ot6/lvoTph4znmoTnqbrmoLwv5byV5Y+36Zeu6aKY77yJClNDUklQVF9CNjQ9JChzZWQgLW4gJ3MvXlNDUklQVF9CNjQ9Ly9wJyAiJEovbWV0YSIgMj4vZGV2L251bGwgfCBoZWFkIC1uIDEpCk49JChzZWQgLW4gJ3MvXk49Ly9wJyAiJEovbWV0YSIgMj4vZGV2L251bGwgfCBoZWFkIC1uIDEpCmNhc2UgIiROIiBpbiAnJ3wqWyEwLTldKikgTj0wIDs7IGVzYWMKU0NSSVBUPSQocHJpbnRmICclcycgIiRTQ1JJUFRfQjY0IiB8IGJhc2U2NCAtZCAyPi9kZXYvbnVsbCkKWyAtZiAiJFNDUklQVCIgXSB8fCB7IHByaW50ZiAnJXMnICcxMjcnID4gIiRKL2RvbmUiOyBleGl0IDEyNzsgfQoKIyAtLS0tIOS7jiBGSUZPIOivu+i+k+WFpe+8iOacgOWkmiA4IOihjO+8ie+8jOWPquWtmOWcqOWGheWtmOmHjCAtLS0tClYxPScnOyBWMj0nJzsgVjM9Jyc7IFY0PScnOyBWNT0nJzsgVjY9Jyc7IFY3PScnOyBWOD0nJwppZiBbICIkTiIgLWd0IDAgXSAmJiBbIC1wICIkSi9pbiIgXTsgdGhlbgogICAgZXhlYyAzPCAiJEovaW4iCiAgICBJRlM9IHJlYWQgLXIgVjEgPCYzIHx8IFYxPScnCiAgICBJRlM9IHJlYWQgLXIgVjIgPCYzIHx8IFYyPScnCiAgICBJRlM9IHJlYWQgLXIgVjMgPCYzIHx8IFYzPScnCiAgICBJRlM9IHJlYWQgLXIgVjQgPCYzIHx8IFY0PScnCiAgICBJRlM9IHJlYWQgLXIgVjUgPCYzIHx8IFY1PScnCiAgICBJRlM9IHJlYWQgLXIgVjYgPCYzIHx8IFY2PScnCiAgICBJRlM9IHJlYWQgLXIgVjcgPCYzIHx8IFY3PScnCiAgICBJRlM9IHJlYWQgLXIgVjggPCYzIHx8IFY4PScnCiAgICBleGVjIDM8Ji0KZmkKCiMgLS0tLSDkvY3nva7lj4LmlbAgJDEuLiROIC0tLS0Kc2V0IC0tCmk9MApmb3IgdiBpbiAiJFYxIiAiJFYyIiAiJFYzIiAiJFY0IiAiJFY1IiAiJFY2IiAiJFY3IiAiJFY4IjsgZG8KICAgIGk9JCgoaSArIDEpKQogICAgWyAiJGkiIC1sZSAiJE4iIF0gJiYgc2V0IC0tICIkQCIgIiR2Igpkb25lCgojIC0tLS0g5omn6KGM77yac3RkaW4g55Sx6Iqx5ous5Y+357uE55Sf5oiQ77yI5LiN6JC955uY77yJ77yM5ZCM5pe25rOo5YWl546v5aKD5Y+Y6YePIC0tLS0KewogICAgaT0wCiAgICBmb3IgdiBpbiAiJFYxIiAiJFYyIiAiJFYzIiAiJFY0IiAiJFY1IiAiJFY2IiAiJFY3IiAiJFY4IjsgZG8KICAgICAgICBpPSQoKGkgKyAxKSkKICAgICAgICBbICIkaSIgLWxlICIkTiIgXSAmJiBwcmludGYgJyVzXG4nICIkdiIKICAgIGRvbmUKfSB8IGVudiBcCiAgICBLU1VfSU5QVVRfMT0iJFYxIiBLU1VfSU5QVVRfMj0iJFYyIiBLU1VfSU5QVVRfMz0iJFYzIiBLU1VfSU5QVVRfND0iJFY0IiBcCiAgICBLU1VfSU5QVVRfNT0iJFY1IiBLU1VfSU5QVVRfNj0iJFY2IiBLU1VfSU5QVVRfNz0iJFY3IiBLU1VfSU5QVVRfOD0iJFY4IiBcCiAgICBLU1VfQ0FSRF9LRVk9IiRWMSIgS1NVX0tFWT0iJFYxIiBDQVJEX0tFWT0iJFYxIiBcCiAgICBzaCAiJFNDUklQVCIgIiRAIgoKZXhpdCAkPwo=';
  var POLL_MS = 700;

  var state = {
    dir: DEFAULT_DIR,
    scripts: [],
    existing: [],
    selected: null,
    inputs: [],
    inputEnabled: false,
    detected: null,
    parseKind: 'shell',
    scriptText: '',
    translatedSh: '',
    confirmPath: '',
    rcTranslated: false,
    interactive: false,
    running: false,
    mode: 'background',
    job: null,
    jobOffset: 0,
    jobDecoder: null,
    jobT0: 0,
    jobPoll: null,
    jobGuard: null,
    daemonOnline: false,
    daemonPid: '',
    channel: 'preview',
    logLines: [],
    streamBuf: '',
    streamCls: '',
    partial: null,
    partialText: '',
    startTime: 0
  };

  /* ---------------- 工具 ---------------- */
  function q(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function nextFrame() { return new Promise(function (r) { requestAnimationFrame(function () { setTimeout(r, 0); }); }); }
  function fmtSize(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(2) + ' MB';
  }
  function joinPath(dir, name) { return String(dir).replace(/\/+$/, '') + '/' + name; }
  function nowTime() {
    return new Date().toLocaleTimeString('zh-CN', { hour12: false });
  }

  var toastTimer;
  function showToast(msg, type) {
    var t = $('#toast');
    t.textContent = msg;
    t.className = 'toast show' + (type ? ' ' + type : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = 'toast'; }, 2600);
  }
  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { }
    document.body.removeChild(ta);
  }
  function copyText(text) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).catch(function () { fallbackCopy(text); });
      } else { fallbackCopy(text); }
      Bridge.toast('已复制');
      showToast('已复制到剪贴板', 'ok');
    } catch (e) { showToast('复制失败', 'err'); }
  }
  function normalize(r) {
    if (r && typeof r === 'object' && ('stdout' in r || 'stderr' in r || 'errno' in r)) {
      return {
        errno: Number(r.errno != null ? r.errno : (r.code != null ? r.code : 0)) || 0,
        stdout: String(r.stdout == null ? '' : r.stdout),
        stderr: String(r.stderr == null ? '' : r.stderr)
      };
    }
    return { errno: 0, stdout: String(r == null ? '' : r), stderr: '' };
  }

  /* ---------------- 卡密库 ----------------
     按「目录|脚本名」分别保存。localStorage 里只有密文、iv 与元数据，
     明文卡密只在内存里；口令本身永不保存，只存随机 salt。
     优先用 Web Crypto AES-GCM；WebView 无 subtle 时降级到 SHA-256 keystream。 */
  function b64FromBytes(bytes) {
    var bin = '';
    for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    try { return btoa(bin); } catch (e) { return ''; }
  }
  function bytesFromB64(s) {
    try {
      var bin = atob(String(s || ''));
      var a = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
      return a;
    } catch (e) { return new Uint8Array(0); }
  }
  function utf8Bytes(s) {
    if (window.TextEncoder) return new TextEncoder().encode(s);
    var esc = unescape(encodeURIComponent(String(s))), a = new Uint8Array(esc.length);
    for (var i = 0; i < esc.length; i++) a[i] = esc.charCodeAt(i);
    return a;
  }
  function fromUtf8(bytes) {
    if (window.TextDecoder) return new TextDecoder('utf-8').decode(bytes);
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    try { return decodeURIComponent(escape(s)); } catch (e) { return s; }
  }
  function catBytes() {
    var n = 0, i, j;
    for (i = 0; i < arguments.length; i++) n += arguments[i].length;
    var out = new Uint8Array(n), o = 0;
    for (i = 0; i < arguments.length; i++) {
      var a = arguments[i];
      for (j = 0; j < a.length; j++) out[o++] = a[j];
    }
    return out;
  }
  function randomBytes(n) {
    var a = new Uint8Array(n);
    if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(a);
    else for (var i = 0; i < n; i++) a[i] = Math.floor(Math.random() * 256);
    return a;
  }

  // 紧凑 SHA-256（仅用于无 Web Crypto 时的兼容加密与口令派生）
  var SHA_K = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  function sha256(bytes) {
    var H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    var l = bytes.length, withPad = (((l + 8) >> 6) + 1) << 6;
    var m = new Uint8Array(withPad);
    m.set(bytes); m[l] = 0x80;
    var bits = l * 8;
    for (var b = 0; b < 8; b++) m[withPad - 1 - b] = (bits / Math.pow(256, b)) & 255;
    var w = new Uint32Array(64);
    for (var off = 0; off < withPad; off += 64) {
      for (var i = 0; i < 16; i++) {
        w[i] = (m[off + i * 4] << 24) | (m[off + i * 4 + 1] << 16) |
               (m[off + i * 4 + 2] << 8) | m[off + i * 4 + 3];
      }
      for (var t = 16; t < 64; t++) {
        var s0 = ((w[t-15] >>> 7) | (w[t-15] << 25)) ^ ((w[t-15] >>> 18) | (w[t-15] << 14)) ^ (w[t-15] >>> 3);
        var s1 = ((w[t-2] >>> 17) | (w[t-2] << 15)) ^ ((w[t-2] >>> 19) | (w[t-2] << 13)) ^ (w[t-2] >>> 10);
        w[t] = (w[t-16] + s0 + w[t-7] + s1) >>> 0;
      }
      var a=H[0],bb=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7];
      for (var k = 0; k < 64; k++) {
        var S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
        var ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + SHA_K[k] + w[k]) >>> 0;
        var S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
        var maj = (a & bb) ^ (a & c) ^ (bb & c);
        var t2 = (S0 + maj) >>> 0;
        h=g; g=f; f=e; e=(d+t1)>>>0; d=c; c=bb; bb=a; a=(t1+t2)>>>0;
      }
      H[0]=(H[0]+a)>>>0; H[1]=(H[1]+bb)>>>0; H[2]=(H[2]+c)>>>0; H[3]=(H[3]+d)>>>0;
      H[4]=(H[4]+e)>>>0; H[5]=(H[5]+f)>>>0; H[6]=(H[6]+g)>>>0; H[7]=(H[7]+h)>>>0;
    }
    var out = new Uint8Array(32);
    for (var z = 0; z < 8; z++) {
      out[z*4] = (H[z] >>> 24) & 255; out[z*4+1] = (H[z] >>> 16) & 255;
      out[z*4+2] = (H[z] >>> 8) & 255; out[z*4+3] = H[z] & 255;
    }
    return out;
  }

  var Vault = (function () {
    var KEY = 'DianXia_Swap_Terminal.vault.v1';
    var db = null, keyBytes = null, aesKey = null;
    var unlocked = false, available = true, useSubtle = false;
    var unlockHooks = [];

    function read() {
      try {
        var raw = window.localStorage.getItem(KEY);
        if (!raw) return null;
        var d = JSON.parse(raw);
        return (d && d.v === 1 && d.items) ? d : null;
      } catch (e) { return null; }
    }
    function write() {
      try { window.localStorage.setItem(KEY, JSON.stringify(db)); return true; }
      catch (e) { available = false; return false; }
    }
    function fresh() {
      return { v: 1, mode: 'device', deviceKey: b64FromBytes(randomBytes(32)),
               salt: '', items: {} };
    }

    async function derive(pass, saltB) {
      if (useSubtle) {
        try {
          var base = await crypto.subtle.importKey('raw', utf8Bytes(pass), 'PBKDF2', false, ['deriveBits']);
          var bits = await crypto.subtle.deriveBits(
            { name: 'PBKDF2', salt: saltB, iterations: 120000, hash: 'SHA-256' }, base, 256);
          return new Uint8Array(bits);
        } catch (e) { useSubtle = false; }
      }
      // 降级：迭代 SHA-256，同样不保存口令
      var h = sha256(catBytes(utf8Bytes(pass), saltB));
      for (var i = 0; i < 12000; i++) h = sha256(catBytes(h, saltB));
      return h;
    }

    async function setKey(bytes) {
      keyBytes = bytes;
      aesKey = null;
      if (useSubtle) {
        try { aesKey = await crypto.subtle.importKey('raw', bytes, 'AES-GCM', false, ['encrypt', 'decrypt']); }
        catch (e) { useSubtle = false; aesKey = null; }
      }
    }

    function xorStream(data, iv) {
      var out = new Uint8Array(data.length), o = 0, ctr = 0;
      while (o < data.length) {
        var block = sha256(catBytes(keyBytes, iv, new Uint8Array([ctr & 255, (ctr >> 8) & 255])));
        for (var i = 0; i < block.length && o < data.length; i++, o++) out[o] = data[o] ^ block[i];
        ctr++;
      }
      return out;
    }
    function macHex(iv, ct) {
      var m = sha256(catBytes(keyBytes, iv, ct));
      var s = '';
      for (var i = 0; i < 16; i++) s += ('0' + m[i].toString(16)).slice(-2);
      return s;
    }

    async function encrypt(plainB) {
      var iv = randomBytes(12);
      if (useSubtle && aesKey) {
        try {
          var ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, aesKey, plainB);
          return { alg: 'aes', iv: b64FromBytes(iv), ct: b64FromBytes(new Uint8Array(ct)) };
        } catch (e) { useSubtle = false; aesKey = null; }
      }
      var x = xorStream(plainB, iv);
      return { alg: 'xor', iv: b64FromBytes(iv), ct: b64FromBytes(x), mac: macHex(iv, x) };
    }

    async function decrypt(rec) {
      var iv = bytesFromB64(rec.iv), ct = bytesFromB64(rec.ct);
      if (rec.alg === 'aes') {
        if (!useSubtle) {
          // 之前用 AES 加密但当前环境降级了 → 尝试重建 CryptoKey
          try {
            aesKey = await crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['decrypt']);
            useSubtle = true;
          } catch (e) { return null; }
        }
        try {
          var pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv }, aesKey, ct);
          return new Uint8Array(pt);
        } catch (e) { return null; }
      }
      if (rec.mac && macHex(iv, ct) !== rec.mac) return null;
      return xorStream(ct, iv);
    }

    async function encodeVals(vals) {
      return encrypt(utf8Bytes(JSON.stringify(vals)));
    }
    async function decodeVals(rec) {
      var b = await decrypt(rec);
      if (!b) return null;
      try {
        var v = JSON.parse(fromUtf8(b));
        return Object.prototype.toString.call(v) === '[object Array]' ? v : null;
      } catch (e) { return null; }
    }

    function fireUnlock() {
      unlockHooks.forEach(function (fn) { try { fn(); } catch (e) { } });
    }

    return {
      init: async function () {
        useSubtle = !!(window.crypto && window.crypto.subtle);
        try { window.localStorage.setItem('__dxst_probe__', '1'); window.localStorage.removeItem('__dxst_probe__'); }
        catch (e) { available = false; }

        // 改名迁移：老版本把卡密存在旧 key 下。整份搬过来即可 —— 数据自带设备密钥 / salt，
        // 搬完仍能原样解密，已记住的卡密不会丢，界面上也不会再出现旧名字。
        try {
          var LEGACY_VAULT_KEY = 'swap_terminal.vault.v1';
          if (!window.localStorage.getItem(KEY)) {
            var legacyVault = window.localStorage.getItem(LEGACY_VAULT_KEY);
            if (legacyVault) {
              window.localStorage.setItem(KEY, legacyVault);
              window.localStorage.removeItem(LEGACY_VAULT_KEY);
            }
          }
        } catch (e) { }
        // 主动探测一次，避免「写入时用 AES、读取时环境降级」造成旧条目解不开
        if (useSubtle) {
          try {
            var probeKey = await crypto.subtle.importKey('raw', new Uint8Array(32), 'AES-GCM', false, ['encrypt']);
            await crypto.subtle.encrypt({ name: 'AES-GCM', iv: new Uint8Array(12) }, probeKey, new Uint8Array(0));
          } catch (e) { useSubtle = false; }
        }
        var loaded = read();
        db = loaded || fresh();
        if (!loaded) write();
        // 空库却还设着口令没有意义，自动退回自动模式，避免「解锁一个空库」
        if (db.mode === 'pass' && !Object.keys(db.items).length) {
          db.mode = 'device';
          db.salt = '';
          write();
        }
        if (db.mode === 'device') {
          var dk = bytesFromB64(db.deviceKey);
          if (!dk.length) { dk = randomBytes(32); db.deviceKey = b64FromBytes(dk); write(); }
          await setKey(dk);
          unlocked = true;
        }
        return available;
      },
      isAvailable: function () { return available; },
      isLocked: function () { return !unlocked; },
      mode: function () { return db ? db.mode : 'device'; },
      isFallback: function () { return !useSubtle; },
      count: function () { return db ? Object.keys(db.items).length : 0; },
      keys: function () { return db ? Object.keys(db.items) : []; },
      meta: function (k) {
        var it = db && db.items[k];
        return it ? { n: it.n || 0, ts: it.ts || 0 } : null;
      },
      get: async function (k) {
        if (!unlocked || !db || !db.items[k]) return null;
        return decodeVals(db.items[k]);
      },
      set: async function (k, vals) {
        if (!unlocked || !available) return false;
        var rec = await encodeVals(vals);
        rec.n = vals.length;
        rec.ts = Date.now();
        db.items[k] = rec;
        return write();
      },
      remove: function (k) {
        if (!db) return false;
        delete db.items[k];
        return write();
      },
      clear: async function () {
        if (!db) return false;
        db.items = {};
        if (db.mode === 'pass') {
          db.mode = 'device';
          db.salt = '';
          await setKey(bytesFromB64(db.deviceKey));
        }
        // 清库后一定是「已解锁 · 本机保存」，不能停留在锁定态
        unlocked = true;
        var ok = write();
        fireUnlock();
        return ok;
      },
      unlock: async function (pass) {
        if (!db || db.mode !== 'pass') return true;
        var saltB = bytesFromB64(db.salt);
        await setKey(await derive(pass, saltB));
        // 用任意一条记录校验口令是否正确
        var ks = Object.keys(db.items);
        if (ks.length) {
          var v = await decodeVals(db.items[ks[0]]);
          if (v === null) { keyBytes = null; aesKey = null; return false; }
        }
        unlocked = true;
        fireUnlock();
        return true;
      },
      setPassphrase: async function (pass) {
        if (!unlocked || !available) return false;
        var plain = {};
        for (var k in db.items) {
          if (!db.items.hasOwnProperty(k)) continue;
          var v = await decodeVals(db.items[k]);
          if (v === null) return false;
          plain[k] = v;
        }
        var nextMode = pass ? 'pass' : 'device';
        var nextKey;
        if (nextMode === 'pass') {
          db.salt = b64FromBytes(randomBytes(16));
          nextKey = await derive(pass, bytesFromB64(db.salt));
        } else {
          db.salt = '';
          nextKey = bytesFromB64(db.deviceKey);
        }
        await setKey(nextKey);
        var rebuilt = {};
        for (var k2 in plain) {
          if (!plain.hasOwnProperty(k2)) continue;
          var rec = await encodeVals(plain[k2]);
          rec.n = plain[k2].length;
          rec.ts = db.items[k2] ? db.items[k2].ts : Date.now();
          rebuilt[k2] = rec;
        }
        db.items = rebuilt;
        db.mode = nextMode;
        unlocked = true;
        write();
        fireUnlock();
        return true;
      },
      forgetAndReset: async function () {
        db = fresh();
        await setKey(bytesFromB64(db.deviceKey));
        unlocked = true;
        write();
        fireUnlock();
      },
      onUnlock: function (fn) { if (typeof fn === 'function') unlockHooks.push(fn); }
    };
  })();

  function vaultKey(name) {
    return state.dir + '|' + name;
  }
  function fmtDate(ts) {
    if (!ts) return '—';
    try { return new Date(ts).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }); }
    catch (e) { return '—'; }
  }

  /* ---------------- 预览模式（普通浏览器） ---------------- */
  function mockExec(cmd) {
    var c = String(cmd);
    var out = '';
    if (c.indexOf('__DIANXIA_SWAP_TERMINAL_OK__') >= 0) {
      out = '__DIANXIA_SWAP_TERMINAL_OK__';
    } else if (c.indexOf('__IMPORT_OK__') >= 0) {
      out = '__IMPORT_OK__';
    } else if (c.indexOf('for d in ') >= 0) {
      out = CANDIDATE_DIRS.slice(0, 3).join('\n');
    } else if (c.indexOf('*.sh') >= 0 || c.indexOf('wc -c') >= 0) {
      out = DEMO_SCRIPTS.map(function (s) { return s.name + '\t' + s.size; }).join('\n');
    } else if (c.indexOf('head -c 262144') >= 0 || c.indexOf('head -n') >= 0) {
      var hit = DEMO_SCRIPTS.filter(function (s) { return c.indexOf(s.name) >= 0; })[0];
      out = hit ? DEMO_CONTENT[hit.name] : '#!/system/bin/sh\necho "hello"';
    } else if (c.indexOf('__TRANS_OK__') >= 0) {
      out = '__TRANS_OK__';
    } else if (c.indexOf('sh ') >= 0) {
      out = DEMO_OUTPUT;
    } else if (c.indexOf('[ -d ') >= 0) {
      out = '1';
    }
    return Promise.resolve({ errno: 0, stdout: out, stderr: '' });
  }

  /* ---------------- 执行桥接 ---------------- */
  var Bridge = {
    esm: null,
    channel: 'preview',

    ksuCallback: function (cmd, opts, timeout) {
      return new Promise(function (resolve, reject) {
        var name = '__swap_cb_' + Math.random().toString(36).slice(2);
        var done = false;
        var timer = setTimeout(function () {
          if (!done) { done = true; delete window[name]; reject(new Error('callback timeout')); }
        }, timeout || 30000);
        window[name] = function (errno, stdout, stderr) {
          if (done) return;
          done = true; clearTimeout(timer); delete window[name];
          resolve({ errno: Number(errno) || 0, stdout: String(stdout || ''), stderr: String(stderr || '') });
        };
        try {
          var r = window.ksu.exec(cmd, JSON.stringify(opts || {}), name);
          // 少数实现虽然接受回调参数，却同步返回结果
          if (typeof r === 'string' || (r && typeof r === 'object' && ('stdout' in r || 'errno' in r))) {
            if (!done) {
              done = true; clearTimeout(timer); delete window[name];
              resolve(typeof r === 'string' ? { errno: 0, stdout: r, stderr: '' } : normalize(r));
            }
          }
        } catch (e) {
          if (!done) { done = true; clearTimeout(timer); delete window[name]; reject(e); }
        }
      });
    },

    probe: function () {
      var self = this;
      return (async function () {
        var marker = '__DIANXIA_SWAP_TERMINAL_OK__';
        var cmd = 'printf ' + q(marker);

        // 0) index.html 中的 module script 预先加载好的 ESM 模块
        var m = window.__ksuEsm;
        for (var w = 0; w < 4 && !m; w++) { await sleep(120); m = window.__ksuEsm; }
        // 1) 官方 kernelsu ESM API（普通浏览器里解析失败可能很慢，加超时兜底）
        if (!m) {
          try {
            m = await Promise.race([
              import('kernelsu').catch(function () { return null; }),
              sleep(1000).then(function () { return null; })
            ]);
          } catch (e) { m = null; }
        }
        // 2) 某些管理器把同一套 API 挂在全局
        if (!m) m = window.kernelsu || window.KernelSU || window.KsuJS || null;

        if (m && typeof m.exec === 'function') {
          try {
            var r = normalize(await m.exec(cmd, {}));
            if ((r.stdout + r.stderr).indexOf(marker) >= 0) {
              self.esm = m; self.channel = 'esm'; return 'esm';
            }
          } catch (e) { }
        }

        // 3) ksu.exec 异步回调
        if (window.ksu && typeof window.ksu.exec === 'function') {
          try {
            var a = await self.ksuCallback(cmd, {}, 3500);
            if ((a.stdout + a.stderr).indexOf(marker) >= 0) { self.channel = 'ksu-async'; return 'ksu-async'; }
          } catch (e) { }
          // 4) ksu.exec 同步阻塞
          try {
            var s = window.ksu.exec(cmd);
            if (String(s || '').indexOf(marker) >= 0) { self.channel = 'ksu-sync'; return 'ksu-sync'; }
          } catch (e) { }
        }

        self.channel = 'preview';
        return 'preview';
      })();
    },

    exec: function (cmd, opts) {
      opts = opts || {};
      if (this.channel === 'preview') return mockExec(cmd);
      if (this.channel === 'esm') {
        return Promise.resolve(this.esm.exec(cmd, opts)).then(normalize);
      }
      if (this.channel === 'ksu-async') return this.ksuCallback(cmd, opts, 180000);
      if (this.channel === 'ksu-sync') {
        return Promise.resolve({ errno: 0, stdout: String(window.ksu.exec(cmd) || ''), stderr: '' });
      }
      return Promise.reject(new Error('no bridge'));
    },

    child: null,
    canWriteStdin: false,

    spawn: function (cmd, args, handlers, opts) {
      this.child = null;
      this.canWriteStdin = false;
      if (this.channel !== 'esm' || !this.esm || typeof this.esm.spawn !== 'function') return false;
      try {
        var child = this.esm.spawn(cmd, args || [], opts || {});
        if (!child || !child.stdout) return false;
        this.child = child;
        this.canWriteStdin = !!(child.stdin && typeof child.stdin.write === 'function');
        child.stdout.on('data', function (d) { handlers.out(String(d)); });
        if (child.stderr) child.stderr.on('data', function (d) { handlers.err(String(d)); });
        child.on('exit', function (c) { handlers.exit(Number(c) || 0); });
        child.on('error', function (e) { handlers.err(String((e && e.message) || e) + '\n'); });
        return true;
      } catch (e) { return false; }
    },

    toast: function (msg) {
      try { if (window.ksu && typeof window.ksu.toast === 'function') window.ksu.toast(String(msg)); } catch (e) { }
      try { if (this.esm && typeof this.esm.toast === 'function') this.esm.toast(String(msg)); } catch (e) { }
    }
  };

  /* ---------------- 终端输出 ---------------- */
  // 每帧只做一次 scrollTop 写入：逐行读 scrollHeight 会触发同步布局，是长输出掉帧的主因
  var scrollPending = false;
  function scheduleTermScroll() {
    if (scrollPending) return;
    scrollPending = true;
    requestAnimationFrame(function () {
      scrollPending = false;
      var term = $('#term');
      term.scrollTop = term.scrollHeight;
    });
  }
  function makeLine(text, cls) {
    var el = document.createElement('div');
    el.className = 'tl' + (cls ? ' ' + cls : '');
    el.textContent = String(text);
    return el;
  }
  function appendTerm(text, cls) {
    $('#term').appendChild(makeLine(text, cls));
    state.logLines.push(String(text));
    scheduleTermScroll();
  }
  function clearTerm() {
    $('#term').textContent = '';
    state.logLines = [];
    state.streamBuf = '';
    state.streamCls = '';
    state.partial = null;
    state.partialText = '';
    scrollPending = false;
  }
  function setBadge(cls, text) {
    var b = $('#termBadge');
    b.className = 'term-badge' + (cls ? ' ' + cls : '');
    b.textContent = text;
  }
  function setTermMeta(t) { $('#termMeta').textContent = t; }

  // 未完成行（如 "请输入卡密: " 不带换行）先落到一个可续写的节点上，
  // 保证脚本提示能立刻显示，后续输出再接在同一行
  function ensurePartial(cls) {
    var lineCls = cls === 'err' ? ' err' : '';
    if (!state.partial) {
      var el = document.createElement('div');
      el.className = 'tl' + lineCls;
      $('#term').appendChild(el);
      state.partial = el;
      state.partialText = '';
    } else if (cls === 'err' && state.partial.className.indexOf('err') < 0) {
      state.partial.className += ' err';
    }
    return state.partial;
  }
  function pushChunk(text, cls) {
    state.streamCls = cls || '';
    var data = state.streamBuf + String(text);
    state.streamBuf = '';
    var parts = data.split('\n');
    var tail = parts.pop();
    for (var i = 0; i < parts.length; i++) {
      if (state.partial) {
        state.partial.textContent = state.partialText + parts[i];
        state.logLines.push(state.partialText + parts[i]);
        state.partial = null;
        state.partialText = '';
      } else {
        appendTerm(parts[i], cls === 'err' ? 'err' : '');
      }
    }
    if (tail) {
      var el = ensurePartial(cls);
      state.partialText += tail;
      el.textContent = state.partialText;
    }
    scheduleTermScroll();
  }
  function flushChunk() {
    if (state.streamBuf) {
      var el = ensurePartial(state.streamCls);
      state.partialText += state.streamBuf;
      el.textContent = state.partialText;
      state.streamBuf = '';
    }
    if (state.partial) {
      state.logLines.push(state.partialText);
      state.partial = null;
      state.partialText = '';
    }
    scheduleTermScroll();
  }
  // 一次性用 DocumentFragment 批量插入，避免逐行 append + 逐行强制布局
  function typeLines(text) {
    var lines = String(text).replace(/\r/g, '').split('\n');
    if (lines.length && lines[lines.length - 1] === '') lines.pop();
    var frag = document.createDocumentFragment();
    var limit = Math.min(lines.length, 500);
    for (var i = 0; i < limit; i++) {
      var low = lines[i].toLowerCase();
      var cls = /error|failed|permission denied|not found|no such/i.test(low) ? 'err' : '';
      frag.appendChild(makeLine(lines[i], cls));
      state.logLines.push(lines[i]);
    }
    if (lines.length > 500) {
      var note = '… 输出过长，已截断';
      frag.appendChild(makeLine(note, 'sys'));
      state.logLines.push(note);
    }
    $('#term').appendChild(frag);
    scheduleTermScroll();
  }

  /* ---------------- 目录扫描与列表 ---------------- */
  function listCmd(dir) {
    return 'd=' + q(dir) + '; if [ -d "$d" ]; then ' +
      'for f in "$d"/*.sh "$d"/*.SH "$d"/*.rc "$d"/*.RC; do ' +
      '[ -f "$f" ] || continue; ' +
      'sz=$(wc -c < "$f" 2>/dev/null | tr -d "[:space:]"); ' +
      'printf "%s\\t%s\\n" "${f##*/}" "$sz"; ' +
      'done; else printf "__NO_DIR__\\n"; fi';
  }
  function parseList(out) {
    var arr = [];
    String(out || '').split('\n').forEach(function (ln) {
      var p = ln.split('\t');
      if (p.length < 2) return;
      var name = p[0].trim();
      if (!/\.(sh|rc)$/i.test(name)) return;
      arr.push({ name: name, size: Number(p[1]) || 0, kind: /\.rc$/i.test(name) ? 'rc' : 'sh' });
    });
    arr.sort(function (a, b) { return a.name.localeCompare(b.name, 'en', { sensitivity: 'base' }); });
    return arr;
  }

  var listSig = '';
  function renderList() {
    var box = $('#scriptList');
    var sig = state.scripts.map(function (s) { return s.name + ':' + s.size; }).join('|');

    // 数据没变（例如只是切换选中项）→ 只切 class，不重建节点、不重播入场动画
    if (sig !== listSig) {
      var frag = document.createDocumentFragment();
      state.scripts.forEach(function (s) {
        var item = document.createElement('button');
        item.type = 'button';
        item.className = 'script-item';
        item.dataset.name = s.name;
        var badge = document.createElement('div');
        badge.className = 'file-badge';
        badge.innerHTML = FILE_SVG;
        var main = document.createElement('div');
        main.className = 'item-main';
        var nm = document.createElement('span');
        nm.className = 'item-name';
        nm.textContent = s.name;
        var sub = document.createElement('div');
        sub.className = 'item-sub';
        var sz = document.createElement('span'); sz.textContent = fmtSize(s.size);
        var sep = document.createElement('span'); sep.className = 'dotsep';
        var tag = document.createElement('span'); tag.className = 'item-tag' + (s.kind === 'rc' ? ' rc' : '');
        tag.textContent = s.kind === 'rc' ? 'RC' : 'SHELL';
        var path = document.createElement('span'); path.textContent = 'root 执行';
        sub.appendChild(sz); sub.appendChild(sep); sub.appendChild(tag); sub.appendChild(path);
        main.appendChild(nm); main.appendChild(sub);
        var arrow = document.createElement('span');
        arrow.className = 'item-arrow';
        arrow.innerHTML = ARROW_SVG;
        item.appendChild(badge); item.appendChild(main); item.appendChild(arrow);
        frag.appendChild(item);
      });
      box.textContent = '';
      box.appendChild(frag);
      listSig = sig;
      $('#scriptCount').textContent = state.scripts.length;
      $('#metaCount').textContent = state.scripts.length + ' 个脚本';
      $('#emptyState').hidden = state.scripts.length > 0;
    }

    var sel = state.selected ? state.selected.name : null;
    box.querySelectorAll('.script-item').forEach(function (el) {
      el.classList.toggle('selected', el.dataset.name === sel);
    });
    updateDock();
  }

  var lastDockName = null;
  function updateDock() {
    var dock = $('#dock');
    var name = state.selected ? state.selected.name : null;
    if (name === lastDockName) return;
    lastDockName = name;
    dock.hidden = !name;
    if (name) $('#dockName').textContent = name;
  }

  function selectByName(name) {
    var old = state.selected ? state.selected.name : null;
    if (old !== name) { state.inputs = []; state.detected = null; }
    state.selected = state.scripts.filter(function (s) { return s.name === name; })[0] || null;
    renderList();
  }

  function renderChips(existing) {
    var box = $('#dirChips');
    box.innerHTML = '';
    var dirs = existing.slice();
    if (dirs.indexOf(state.dir) < 0) dirs.unshift(state.dir);
    dirs.forEach(function (d) {
      var b = document.createElement('button');
      b.type = 'button';
      var short = d.replace(/^\/data\/adb\/modules\//, '~/').replace(/^\/sdcard\//, 'SD/').replace(/^\/data\/local\/tmp\//, 'TMP/');
      b.className = 'chip' + (d === state.dir ? ' active' : '');
      b.textContent = short;
      b.title = d;
      b.addEventListener('click', function () {
        state.dir = d;
        $('#dirInput').value = d;
        renderChips(existing);
        scan();
      });
      box.appendChild(b);
    });
  }

  async function scan() {
    clearPreviewCache();
    var btn = $('#refreshBtn');
    btn.classList.add('spin');
    try {
      var r = await Bridge.exec(listCmd(state.dir));
      var out = String(r.stdout || '');
      if (out.indexOf('__NO_DIR__') >= 0) {
        state.scripts = [];
        $('#metaText').textContent = '目录不存在 · 可导入脚本自动创建';
        showToast('目录不存在，导入脚本时会自动创建', 'err');
      } else {
        state.scripts = parseList(out);
        $('#metaText').textContent = state.dir;
      }
      if (state.selected && !state.scripts.some(function (s) { return s.name === state.selected.name; })) {
        state.selected = null;
      }
      renderList();
    } catch (e) {
      state.scripts = [];
      renderList();
      $('#metaText').textContent = '扫描失败';
      showToast('扫描失败：' + e.message, 'err');
    } finally {
      btn.classList.remove('spin');
    }
  }

  /* ---------------- .rc 识别与转译 ---------------- */
  // Android init 语言不是 shell：on/service 段、setprop/write/mkdir 等动作需要转成 sh 才能"立刻跑"。
  // 这里只转译「可立即执行的动作」，事件触发、服务守护等 init 语义明确跳过并提示。
  var INIT_SECTION = /^(on|service|import)\b/;
  var SERVICE_OPT = /^(class|user|group|oneshot|disabled|seclabel|socket|file|mkdir|writepid|setenv|priority|console|interface|updatable|task_profiles|rlimit|reboot_on_failure|oom_score_adjust|override|memcg|shutdown|onrestart|critical|stdin|stdio|gentle_kill|capabilities)\b/;
  var SHELL_HINT = /^(#!\s*\/\S*sh\b|echo\b|printf\b|read\b|if\s+\[|for\s+\w|while\s+\[|case\b|function\b|export\b|local\b|source\b|\.\s+\/|exit\b|return\b)/;

  function detectScriptType(text, name) {
    var lines = String(text || '').split(/\r?\n/);
    var initHits = 0, shellHits = 0;
    lines.forEach(function (ln) {
      var t = ln.trim();
      if (!t || t.charAt(0) === '#') return;
      if (/^(on|service|import)\b/.test(t)) initHits += 2;
      else if (/^(class_start|class_stop|class_reset|exec_start|load_persist_props|trigger|bootchart|ifup|sysclktz|setprop|write|symlink|insmod|copy|rmdir|chown|chmod|mkdir|mount|umount|start|stop|restart|exec|wait|loglevel|setrlimit)\b/.test(t)) initHits++;
      if (SHELL_HINT.test(t) || /\$\(|\$\{|;\s*do\b|\|\s*while\b/.test(t)) shellHits++;
    });
    // shebang 明确写了 sh，就当 shell（哪怕里面调用了 setprop）
    if (/^#!\s*\/\S*sh\b/m.test(String(text || ''))) return { kind: 'shell', why: '检测到 sh shebang' };
    var hasSections = /^(on|service|import)\s/m.test(String(text || ''));
    // 有 on/service/import 段，且没有明显 shell 结构 → init 语言
    if (hasSections && initHits >= 2 && shellHits === 0) {
      return { kind: 'initrc', why: '检测到 ' + initHits + ' 处 init 语法 · 含 on/service 段' };
    }
    // 纯动作列表：要足够多的 init 命令且完全没有 shell 特征才判 initrc
    if (initHits >= 3 && shellHits === 0) {
      return { kind: 'initrc', why: '检测到 ' + initHits + ' 处 init 动作' };
    }
    return { kind: 'shell', why: '按 Shell 解析（未发现 init 段结构）' };
  }

  function sq(s) { return q(s); }  // shell 单引号转义，复用已有的 q()

  // 把 init 动作转成等价 shell；未知行一律注释掉，绝不盲目当命令执行
  function translateInitRc(text) {
    var out = ['#!/system/bin/sh', '# 由交换终端从 .rc 转译生成 · 仅执行可立即执行的动作'];
    var notes = [];
    var inService = false, svcName = '';
    var lines = String(text || '').split(/\r?\n/);

    lines.forEach(function (raw, idx) {
      var t = raw.trim();
      if (!t) return;
      if (t.charAt(0) === '#') { out.push('# ' + raw.trim()); return; }

      // service 整段跳过：启动守护是 init 的职责，直接跑会改变脚本语义
      if (/^service\b/.test(t)) {
        inService = true;
        svcName = t.split(/\s+/)[1] || '(unnamed)';
        out.push('# [跳过] service ' + svcName + ' —— 需由 init 管理，不在本次执行');
        notes.push('service ' + svcName + ' 未启动（需放进模块根目录由 init 加载）');
        return;
      }
      if (inService) {
        if (SERVICE_OPT.test(t)) { out.push('# [跳过] 服务选项: ' + t); return; }
        // 出现新的段则说明 service 段结束
        if (INIT_SECTION.test(t)) inService = false;
        else { out.push('# [跳过] service 段内: ' + t); return; }
      }

      // on / import 段：触发器本身不生效，但 on 段内的动作照常执行
      if (/^on\b/.test(t)) {
        out.push('# [段] ' + t + ' —— 事件触发不生效，段内动作会立即执行');
        notes.push('「' + t + '」的触发条件不生效，段内动作按顺序执行一次');
        return;
      }
      if (/^import\b/.test(t)) {
        out.push('# [跳过] import ' + t.split(/\s+/).slice(1).join(' ') + ' —— 请单独选择被导入的文件');
        notes.push('import 未展开，请单独运行被导入的 .rc');
        return;
      }

      var w = t.split(/\s+/);
      var cmd = w[0];
      var a = w.slice(1);
      function note(s) { notes.push(s); out.push('# [跳过] ' + t + ' —— ' + s); }

      switch (cmd) {
        case 'setprop':
          out.push('setprop ' + sq(a[0] || '') + ' ' + sq(a.slice(1).join(' ')));
          break;
        case 'write':
          out.push('printf %s ' + sq(a.slice(1).join(' ')) + ' > ' + sq(a[0] || ''));
          break;
        case 'mkdir':
          out.push('mkdir -p ' + sq(a[0] || ''));
          if (a[1]) out.push('chmod ' + sq(a[1]) + ' ' + sq(a[0]));
          if (a[2]) out.push('chown ' + sq(a[2] + (a[3] ? ':' + a[3] : '')) + ' ' + sq(a[0]));
          break;
        case 'chmod': out.push('chmod ' + sq(a[0] || '') + ' ' + sq(a[1] || '')); break;
        case 'chown': out.push('chown ' + sq(a[0] + (a[1] ? ':' + a[1] : '')) + ' ' + sq(a[2] || '')); break;
        case 'symlink': out.push('ln -sfn ' + sq(a[0] || '') + ' ' + sq(a[1] || '')); break;
        case 'copy': out.push('cp -f ' + sq(a[0] || '') + ' ' + sq(a[1] || '')); break;
        case 'rm': out.push('rm -f ' + sq(a[0] || '')); break;
        case 'rmdir': out.push('rmdir ' + sq(a[0] || '') + ' 2>/dev/null'); break;
        case 'exec': {
          var dash = a.indexOf('--');
          if (dash < 0) {
            note('exec 缺少 -- 分隔符，避免误执行');
            break;
          }
          var rest = a.slice(dash + 1);
          if (rest.length) out.push(rest.join(' '));
          else note('exec 未解析出命令');
          break;
        }
        case 'exec_start': note('exec_start 需 init 调度'); break;
        case 'start': case 'stop': case 'restart':
          out.push(cmd + ' ' + sq(a[0] || ''));
          break;
        case 'class_start': case 'class_stop': case 'class_reset':
          note(cmd + ' 需 init 的 class 调度');
          break;
        case 'trigger': note('trigger 无法在 shell 中触发 init 事件'); break;
        case 'wait':
          out.push('i=0; while [ ! -e ' + sq(a[0] || '') + ' ] && [ "$i" -lt 100 ]; do sleep 0.1; i=$((i+1)); done');
          break;
        case 'mount':
          out.push('mount' + (a[0] && a[0] !== 'all' ? ' -t ' + sq(a[0]) : '') +
            (a[1] ? ' ' + sq(a[1]) : '') + (a[2] ? ' ' + sq(a[2]) : '') +
            (a.length > 3 ? ' ' + a.slice(3).map(sq).join(' ') : ''));
          break;
        case 'umount': out.push('umount ' + sq(a[0] || '')); break;
        case 'insmod': out.push('insmod ' + a.map(sq).join(' ')); break;
        case 'ifup': out.push('ifconfig ' + sq(a[0] || '') + ' up'); break;
        case 'loglevel': out.push('printf %s ' + sq(a[0] || '') + ' > /proc/sys/kernel/printk'); break;
        case 'load_persist_props': case 'bootchart': case 'sysclktz': case 'setrlimit':
          note(cmd + ' 是 init 专属动作');
          break;
        default:
          note('未识别的 init 语句（第 ' + (idx + 1) + ' 行），已注释以保证安全');
      }
    });

    return { sh: out.join('\n') + '\n', notes: notes };
  }

  /* ---------------- 脚本输入 / 卡密 ---------------- */
  // 从脚本内容里探测 read 语句与 $1 位置参数，用于自动准备输入框
  function detectInputs(text) {
    var reads = 0, args = false;
    String(text).split(/\r?\n/).forEach(function (ln) {
      var t = ln.trim();
      if (!t || t.charAt(0) === '#') return;
      var code = t.replace(/#.*$/, '').trim();
      if (/^(?:IFS=\S*\s+)?(?:read\b|read\s+-)/.test(code) ||
          /(?:^|[;&|]\s*)(?:read\b|read\s+-)/.test(code)) reads++;
      if (/\$\{?[1-9]\}?/.test(code)) args = true;
    });
    return { reads: reads, args: args, count: Math.min(Math.max(reads, args ? 1 : 0), 8) };
  }

  function collectInputs() {
    var arr = [];
    document.querySelectorAll('#inputRows input').forEach(function (el) {
      arr.push(String(el.value).replace(/[\r\n]+/g, ' '));
    });
    state.inputs = arr;
    return arr;
  }

  function renderInputRows(n) {
    var box = $('#inputRows');
    var count = Math.min(Math.max(n, 1), 8);
    box.textContent = '';
    for (var i = 0; i < count; i++) {
      var row = document.createElement('div');
      row.className = 'input-row';
      var idx = document.createElement('span');
      idx.className = 'row-idx';
      idx.textContent = ('0' + (i + 1)).slice(-2);
      var inp = document.createElement('input');
      inp.type = 'password';
      inp.autocomplete = 'off';
      inp.autocapitalize = 'off';
      inp.spellcheck = false;
      inp.placeholder = i === 0 ? '第 1 次输入，如卡密' : '第 ' + (i + 1) + ' 次输入';
      inp.dataset.idx = i;
      inp.value = state.inputs[i] || '';
      var eye = document.createElement('button');
      eye.type = 'button';
      eye.className = 'row-btn eye';
      eye.title = '显示 / 隐藏';
      eye.innerHTML = EYE_SVG;
      var del = document.createElement('button');
      del.type = 'button';
      del.className = 'row-btn del';
      del.title = '删除这一行';
      del.innerHTML = DEL_SVG;
      row.appendChild(idx); row.appendChild(inp); row.appendChild(eye); row.appendChild(del);
      box.appendChild(row);
    }
    collectInputs();
  }

  function setInputEnabled(on) {
    state.inputEnabled = !!on;
    $('#inputToggle').checked = !!on;
    $('#inputBody').hidden = !on;
    if (on && !$('#inputRows').children.length) {
      renderInputRows((state.detected && state.detected.count) || 1);
    }
  }

  // 一次性把输入同时喂给 stdin / 位置参数 / 环境变量，兼容各种写法
  function buildRunCommand(path, vals) {
    if (!vals.length) return 'sh ' + q(path) + ' 2>&1';
    var envParts = vals.map(function (v, i) { return 'KSU_INPUT_' + (i + 1) + '=' + q(v); });
    envParts.push('KSU_CARD_KEY=' + q(vals[0]));
    envParts.push('KSU_KEY=' + q(vals[0]));
    envParts.push('CARD_KEY=' + q(vals[0]));
    var quoted = vals.map(function (v) { return q(v); });
    return 'export ' + envParts.join(' ') + '; ' +
      'printf ' + q('%s\\n') + ' ' + quoted.join(' ') +
      ' | sh ' + q(path) + ' ' + quoted.join(' ') + ' 2>&1';
  }

  function buildEnv(vals) {
    var env = {};
    vals.forEach(function (v, i) { env['KSU_INPUT_' + (i + 1)] = v; });
    if (vals.length) {
      env.KSU_CARD_KEY = vals[0];
      env.KSU_KEY = vals[0];
      env.CARD_KEY = vals[0];
    }
    return env;
  }

  /* ---------------- 卡密库 UI ---------------- */
  function renderVaultBadge() {
    var n = Vault.count();
    var el = $('#vaultCount');
    el.hidden = n === 0;
    el.textContent = n;
  }

  function renderVaultList() {
    var box = $('#vaultList');
    box.textContent = '';
    var keys = Vault.keys();
    $('#vaultItemCount').textContent = keys.length + ' 份';
    if (!keys.length) {
      var empty = document.createElement('div');
      empty.className = 'vault-empty';
      empty.textContent = '还没有保存的卡密 · 在脚本确认页勾选「记住这份卡密」即可';
      box.appendChild(empty);
      return;
    }
    keys.forEach(function (k) {
      var m = Vault.meta(k) || { n: 0, ts: 0 };
      var name = k.split('|').pop();
      var row = document.createElement('div');
      row.className = 'vi';
      var ico = document.createElement('span');
      ico.className = 'vi-ico';
      ico.innerHTML = FILE_SVG;
      var main = document.createElement('div');
      main.className = 'vi-main';
      var strong = document.createElement('strong');
      strong.textContent = name;
      var small = document.createElement('small');
      small.textContent = m.n + ' 项输入 · ' + fmtDate(m.ts);
      main.appendChild(strong); main.appendChild(small);
      var del = document.createElement('button');
      del.className = 'vi-del';
      del.title = '删除这条';
      del.innerHTML = DEL_SVG;
      del.addEventListener('click', function () {
        Vault.remove(k);
        renderVaultList();
        renderVaultBadge();
        showToast('已删除 ' + name + ' 的卡密', 'ok');
        if (state.confirmPath && vaultKey(state.selected ? state.selected.name : '') === k) {
          $('#rememberCheck').checked = false;
          $('#rememberHint').textContent = '勾一次，以后打开自动填好';
        }
      });
      row.appendChild(ico); row.appendChild(main); row.appendChild(del);
      box.appendChild(row);
    });
  }

  function renderVaultUI() {
    var locked = Vault.isLocked();
    var mode = Vault.mode();
    var n = Vault.count();
    var st = $('#vaultStatus');
    st.className = 'vault-status' + (locked ? ' locked' : '');
    var label = locked ? '已锁定 · 需输入保管口令'
      : (mode === 'pass' ? '已解锁 · 口令保护' : '已解锁 · 本机保存（无口令）');
    if (!Vault.isAvailable()) label = '当前环境不支持本地存储，无法保存';
    if (Vault.isFallback()) label += ' · 兼容加密';
    $('#vaultStatusText').textContent = label + ' · ' + n + ' 份记录';
    $('#vaultUnlock').hidden = !locked;
    $('#vaultListWrap').hidden = locked || !Vault.isAvailable();
    $('#vaultPassBlock').hidden = locked || !Vault.isAvailable() || n === 0;
    $('#vaultRemovePassBtn').hidden = mode !== 'pass';
    $('#vaultNewPass').value = '';
    $('#vaultPass').value = '';
    $('#vaultErr').hidden = true;
    $('#vaultSetPassBtn').textContent = mode === 'pass' ? '修改' : '设置';
    $('#vaultPassTip').textContent = mode === 'pass'
      ? '已设置保管口令。每次重新打开 WebUI 需要输入一次，口令本身不会保存。'
      : '不设口令：打开 WebUI 自动填充，但等同明文存在本机，root 可读取。设口令后每次打开需输一次。';
    renderVaultList();
    renderVaultBadge();
  }

  function openVault() {
    renderVaultUI();
    $('#vaultModal').hidden = false;
  }
  function closeVault() {
    $('#vaultModal').hidden = true;
    renderVaultBadge();
  }

  // ---- 危险操作二次确认（清除全部 / 忘记口令重置）----
  // 只在这里真正执行破坏性动作，取消 / 遮罩 / Escape 一律不动数据。
  var dangerAction = null;
  function openDanger(cfg) {
    dangerAction = cfg.action;
    $('#dangerTitle').textContent = cfg.title || '确认操作？';
    $('#dangerDesc').textContent = cfg.desc || '';
    // detail 用受控的 textContent 片段拼装，不注入 HTML
    var d = $('#dangerDetail');
    d.textContent = '';
    (cfg.details || []).forEach(function (line) {
      var row = document.createElement('div');
      row.textContent = line;
      d.appendChild(row);
    });
    d.hidden = !(cfg.details && cfg.details.length);
    $('#dangerOkBtn').textContent = cfg.ok || '确认清除';
    $('#dangerModal').hidden = false;
  }
  function closeDanger() {
    $('#dangerModal').hidden = true;
    dangerAction = null;
  }

  // 确认页：把该脚本已记住的卡密填进输入框
  async function applyVaultFill(forceRows) {
    if (!state.selected) return false;
    var k = vaultKey(state.selected.name);
    if (Vault.isLocked()) {
      var has = Vault.meta(k);
      $('#vaultLockHint').hidden = !has;
      if (has) $('#rememberHint').textContent = '已保存 ' + (has.n || 0) + ' 项 · 卡密库锁定中';
      return false;
    }
    $('#vaultLockHint').hidden = true;
    var vals = await Vault.get(k);
    if (!vals || !vals.length) {
      $('#rememberHint').textContent = '勾一次，以后打开自动填好';
      return false;
    }
    state.inputs = vals.slice();
    $('#rememberCheck').checked = true;
    $('#rememberHint').textContent = '已记住 ' + vals.length + ' 项 · 本次自动填好';
    // 输入区可能因检测尚未展开，这里保证展开并渲染对应行数
    setInputEnabled(true);
    renderInputRows(Math.max(vals.length, state.detected ? state.detected.count : 1));
    return true;
  }

  // 关闭确认页 / 执行前持久化（勾选=存，取消勾选=删该条）
  async function persistRemembered() {
    if (!state.selected || !Vault.isAvailable()) return;
    var k = vaultKey(state.selected.name);
    var on = $('#rememberCheck').checked;
    if (Vault.isLocked()) return;
    if (!on) {
      if (Vault.meta(k)) Vault.remove(k);
      renderVaultBadge();
      return;
    }
    // 保留空行：脚本第 N 次 read 拿到空值也是一种有效输入，不能压缩掉位置
    var vals = collectInputs();
    if (!vals.some(function (v) { return v !== ''; })) {
      showToast('没有可保存的输入内容', 'err');
      return;
    }
    await Vault.set(k, vals);
    renderVaultBadge();
  }

  /* ---------------- 二次确认 ---------------- */
  // 预览文本 + 输入检测结果按脚本路径缓存，反复打开确认页不再等 shell 往返
  var previewCache = {};
  function clearPreviewCache() { previewCache = {}; }

  // 预览只读前 80 行，但 init 转译需要完整文件，额外读一次（上限 256KB）
  async function loadFullText(p) {
    if (previewCache[p] && previewCache[p].full) return previewCache[p].full;
    try {
      var r = await Bridge.exec('head -c 262144 ' + q(p) + ' 2>/dev/null', {});
      var full = String(r.stdout || '');
      if (previewCache[p]) previewCache[p].full = full;
      return full;
    } catch (e) { return ''; }
  }

  async function writeTranslated(tmp, sh) {
    var b64 = b64EncodeUtf8(sh);
    if (!b64) return false;
    var cmd = 'mkdir -p ' + q(JOB_ROOT + '/translated') + '; ' +
      'printf %s ' + q(b64) + ' | base64 -d > ' + q(tmp) + ' && ' +
      'chmod 644 ' + q(tmp) + ' && printf __TRANS_OK__';
    var r = await Bridge.exec(cmd, {});
    return String(r.stdout || '').indexOf('__TRANS_OK__') >= 0;
  }

  function renderTranslation() {
    var wrap = $('#transWrap'), note = $('#rcNote');
    if (state.parseKind !== 'initrc') {
      wrap.hidden = true;
      note.hidden = true;
      state.translatedSh = '';
      return;
    }
    var t = translateInitRc(state.scriptText || '');
    state.translatedSh = t.sh;
    $('#transPreview').textContent = t.sh;
    $('#transLines').textContent = t.sh.trim().split('\n').length + ' 行';
    wrap.hidden = false;
    // 脚本内容一律走 textContent，不拼 HTML
    var msg = 'init 语义说明：「on 事件触发」「service 守护」「property: 触发器」不会生效，' +
      '只把段内可立即执行的动作按顺序跑一次。未识别的语句会被注释掉，不会盲目执行。' +
      '若要完整 init 行为，请把 .rc 放到模块根目录由系统开机加载。';
    if (t.notes.length) {
      msg += '\n跳过 ' + t.notes.length + ' 项：' + t.notes.slice(0, 3).join('；') +
        (t.notes.length > 3 ? ' …' : '');
    }
    note.textContent = msg;
    note.hidden = false;
  }

  function applyPreview(text, det) {
    $('#cfPreview').textContent = text.trim() ? text : '（空文件或无法读取内容）';
    $('#cfLines').textContent = '前 ' + text.replace(/\s+$/, '').split('\n').length + ' 行';
    state.detected = det;
    state.scriptText = text;

    // 自动识别 .rc：内容其实还是 shell 就照跑；是 init 语言则默认转译
    var type = detectScriptType(text, state.selected ? state.selected.name : '');
    state.parseKind = type.kind;
    var badge = $('#typeBadge');
    badge.className = 'type-badge' + (type.kind === 'initrc' ? ' rc' : '');
    badge.textContent = type.kind === 'initrc' ? 'ANDROID INIT.RC' : 'SHELL 脚本';
    $('#typeWhy').textContent = type.why;
    document.querySelectorAll('input[name="parseKind"]').forEach(function (el) {
      el.checked = (el.value === type.kind);
      el.closest('.parse-opt').classList.toggle('active', el.checked);
    });
    renderTranslation();

    if (type.kind === 'initrc' && state.confirmPath) {
      var p = state.confirmPath;
      loadFullText(p).then(function (full) {
        // 用户可能已经切到别的文件 / 关了弹窗
        if (state.confirmPath !== p || $('#confirmModal').hidden) return;
        if (full) {
          state.scriptText = full;
          renderTranslation();
          $('#typeWhy').textContent = type.why + ' · 已读取全文转译';
        }
      });
    }
    var hint = $('#detectHint');
    if (det.reads) {
      hint.textContent = '检测到 ' + det.reads + ' 处 read · 已备好 ' + det.count + ' 个输入框';
      hint.className = 'detected';
    } else if (det.args) {
      hint.textContent = '检测到位置参数 $1 · 输入值会一并传入';
      hint.className = 'detected';
    } else {
      hint.textContent = '未检测到输入语句，需要卡密请手动开启';
      hint.className = '';
    }
    if (det.count) {
      renderInputRows(det.count);
      setInputEnabled(true);
    }
  }

  function openConfirm() {
    if (!state.selected || state.running) return;
    var p = joinPath(state.dir, state.selected.name);
    state.confirmPath = p;
    $('#cfName').textContent = state.selected.name;
    $('#cfPath').textContent = p;
    $('#agreeCheck').checked = false;
    $('#confirmBtn').disabled = true;
    document.querySelectorAll('input[name="runMode"]').forEach(function (el) {
      el.checked = (el.value === state.mode);
      el.closest('.mode-opt').classList.toggle('active', el.checked);
    });
    $('#inputRows').textContent = '';
    setInputEnabled(false);
    state.inputs = [];
    $('#rememberCheck').checked = false;
    $('#rememberHint').textContent = '勾一次，以后打开自动填好';
    $('#vaultLockHint').hidden = true;
    state.detected = null;
    state.scriptText = '';
    state.translatedSh = '';
    $('#typeBadge').className = 'type-badge unknown';
    $('#typeBadge').textContent = '识别中…';
    $('#typeWhy').textContent = '正在分析脚本内容';
    $('#transWrap').hidden = true;
    $('#rcNote').hidden = true;
    $('#confirmModal').hidden = false;

    // 命中缓存：弹窗显示时内容已经填好，不出现「读取中」闪动
    var hit = previewCache[p];
    if (hit) { applyPreview(hit.text, hit.det); applyVaultFill(); return; }

    $('#cfLines').textContent = '读取中…';
    $('#cfPreview').textContent = '正在读取脚本内容…';
    $('#detectHint').textContent = '正在检测脚本输入…';
    $('#detectHint').className = '';
    Bridge.exec('head -n 80 ' + q(p) + ' 2>/dev/null | head -c 16000')
      .then(function (r) {
        var text = String(r.stdout || '');
        var det = detectInputs(text);
        previewCache[p] = { text: text, det: det };
        applyPreview(text, det);
        applyVaultFill();
      })
      .catch(function () {
        $('#cfPreview').textContent = '（读取失败，请确认文件可读）';
        $('#cfLines').textContent = '—';
        $('#detectHint').textContent = '预览读取失败，可手动开启输入区';
        $('#typeBadge').textContent = '未知';
        $('#typeWhy').textContent = '读取失败，请手动选择解析方式';
      });
  }
  async function closeConfirm() {
    collectInputs();
    try { await persistRemembered(); } catch (e) { }
    $('#confirmModal').hidden = true;
  }

  /* ---------------- 后台作业 ---------------- */
  function makeJobId() {
    return 'job_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
  }
  function newDecoder() {
    try { return new TextDecoder('utf-8'); } catch (e) { return null; }
  }
  function decodeChunk(bytes, final) {
    if (state.jobDecoder) {
      try { return state.jobDecoder.decode(bytes, { stream: !final }); } catch (e) { }
    }
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    try { return decodeURIComponent(escape(s)); } catch (e) { return s; }
  }
  function b64ToBytes(s) {
    var bin;
    try { bin = atob(String(s || '')); } catch (e) { return new Uint8Array(0); }
    var arr = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return arr;
  }

  // 模块升级后必须把新版执行器覆盖过去，否则 /data/local/tmp 里会残留旧版
  async function ensureRunner() {
    var cmd = 'mkdir -p ' + q(JOBS_DIR) + '; chmod 700 ' + q(JOB_ROOT) + ' ' + q(JOBS_DIR) + ' 2>/dev/null; ' +
      'if [ -f ' + q(MODULE_DIR + '/runner.sh') + ' ]; then ' +
        'cp -f ' + q(MODULE_DIR + '/runner.sh') + ' ' + q(RUNNER_PATH) + '; ' +
      'else printf %s ' + q(RUNNER_B64) + ' | base64 -d > ' + q(RUNNER_PATH) + '; fi; ' +
      'if [ -f ' + q(MODULE_DIR + '/watchdog.sh') + ' ]; then ' +
        'cp -f ' + q(MODULE_DIR + '/watchdog.sh') + ' ' + q(JOB_ROOT + '/watchdog.sh') + '; fi; ' +
      'chmod 755 ' + q(RUNNER_PATH) + ' ' + q(JOB_ROOT + '/watchdog.sh') + ' 2>/dev/null; ' +
      'printf __RUNNER_OK__';
    var r = await Bridge.exec(cmd, {});
    return String(r.stdout || '').indexOf('__RUNNER_OK__') >= 0;
  }

  // ---- 系统守护心跳 ----
  async function checkDaemon() {
    if (Bridge.channel === 'preview') return true;
    try {
      var r = await Bridge.exec(
        'printf %s "$(cat ' + q(JOB_ROOT + '/daemon.alive') + ' 2>/dev/null)"; printf "|"; ' +
        'date +%s; printf "|"; cat ' + q(JOB_ROOT + '/daemon.pid') + ' 2>/dev/null; ' +
        'printf "|"; cat ' + q(JOB_ROOT + '/daemon.version') + ' 2>/dev/null', {});
      var p = String(r.stdout || '').split('|');
      var hb = parseInt(p[0], 10) || 0;
      var now = parseInt(p[1], 10) || Math.floor(Date.now() / 1000);
      var pid = (p[2] || '').trim();
      var ver = (p[3] || '').trim();
      state.daemonOnline = !!(hb && ver === '2' && now - hb >= 0 && now - hb <= 20);
      state.daemonPid = pid;
    } catch (e) {
      state.daemonOnline = false;
    }
    renderDaemonBar();
    return state.daemonOnline;
  }

  function renderDaemonBar() {
    var bar = $('#daemonBar'), txt = $('#daemonText'), btn = $('#daemonBtn');
    if (Bridge.channel === 'preview') {
      bar.className = 'daemon-bar preview';
      txt.textContent = '预览模式 · 无需守护';
      btn.hidden = true;
      return;
    }
    if (state.daemonOnline) {
      bar.className = 'daemon-bar online';
      txt.textContent = '系统守护在线' + (state.daemonPid ? ' · PID ' + state.daemonPid : '') + ' · 清理 App 不影响脚本';
      btn.hidden = true;
    } else {
      bar.className = 'daemon-bar offline';
      txt.textContent = '守护未运行 · 点右侧「拉起守护」即可';
      btn.hidden = false;
    }
  }

  async function bootDaemon() {
    showToast('正在拉起系统守护…');
    try {
      var cmd = 'mkdir -p ' + q(JOBS_DIR) + '; ' +
        'cp -f ' + q(MODULE_DIR + '/watchdog.sh') + ' ' + q(JOB_ROOT + '/watchdog.sh') + ' 2>/dev/null; ' +
        'cp -f ' + q(MODULE_DIR + '/runner.sh') + ' ' + q(RUNNER_PATH) + ' 2>/dev/null; ' +
        'chmod 755 ' + q(JOB_ROOT + '/watchdog.sh') + ' ' + q(RUNNER_PATH) + ' 2>/dev/null; ' +
        'nohup setsid sh ' + q(JOB_ROOT + '/watchdog.sh') + ' >/dev/null 2>&1 < /dev/null & ' +
        'printf __BOOTED__';
      await Bridge.exec(cmd, {});
      await sleep(1200);
      var ok = await checkDaemon();
      showToast(ok ? '守护已拉起' : '仍未在线，建议重启设备一次', ok ? 'ok' : 'err');
    } catch (e) {
      showToast('拉起失败：' + e.message, 'err');
    }
  }

  // ---- 投递任务 ----
  // WebUI 不再自己起脚本！只写 meta（不含卡密）+ ready 标记，
  // 由 ksud 派生的 watchdog 认领后 fork runner 执行。
  // 卡密经 FIFO 内核缓冲传给 runner，不写入任何磁盘文件。
  function b64EncodeUtf8(s) {
    try {
      var bytes = new TextEncoder().encode(s);
      var bin = '';
      for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
      return btoa(bin);
    } catch (e) {
      try { return btoa(unescape(encodeURIComponent(s))); } catch (e2) { return ''; }
    }
  }

  function buildSubmitCommand(path, vals, job) {
    var n = vals.length;
    var meta = 'SCRIPT_B64=' + b64EncodeUtf8(path) + '\\nN=' + n + '\\n';
    var fifoPart = '';
    if (n > 0) {
      fifoPart = 'mkfifo "$J/in" 2>/dev/null || { printf __FIFO_FAIL__; exit 1; }; ';
    }
    // 等守护认领（最多约 4 秒）；没认领就明确失败，避免卡密丢在无名管道里
    var waitPart = 'i=0; while [ ! -f "$J/claimed" ] && [ "$i" -lt 40 ]; do ' +
      'sleep 0.1 2>/dev/null || usleep 100000 2>/dev/null || sleep 1; i=$((i+1)); done; ' +
      'if [ ! -f "$J/claimed" ]; then rm -f "$J/ready" "$J/in" "$J/meta"; printf __NO_DAEMON__; exit 1; fi; ';
    var feedPart = n > 0
      ? 'printf ' + q('%s\\n') + ' ' + vals.map(function (v) { return q(v); }).join(' ') + ' > "$J/in"; '
      : '';

    return 'R=' + q(JOB_ROOT) + '; J=' + q(job) + '; ' +
      'mkdir -p "$J"; : > "$J/out"; ' +
      'rm -f "$J/done" "$J/pid" "$J/claimed" "$J/ready" "$J/in" "$J/meta"; ' +
      'printf ' + q(meta) + ' > "$J/meta"; ' +
      'printf %s ' + q(job) + ' > "$R/current.job"; ' +
      fifoPart +
      'touch "$J/ready"; ' +
      waitPart + feedPart +
      'printf __SUBMITTED__';
  }

  // 一次轮询拿全：块内偏移 | 增量输出(base64) | 结束码 | 文件总字节
  function buildPollCommand(job, off) {
    var blk = Math.floor(off / 512), rem = off % 512;
    return 'J=' + q(job) + '; printf %s ' + q(String(rem)) + '; printf "|"; ' +
      'dd if="$J/out" bs=512 skip=' + blk + ' count=32 2>/dev/null | base64 | tr -d ' + q('\\n') + '; ' +
      'printf "|"; if [ -f "$J/done" ]; then cat "$J/done"; else printf "-"; fi; ' +
      'printf "|"; wc -c < "$J/out" 2>/dev/null | tr -d "[:space:]"';
  }

  function stopPolling() {
    if (state.jobPoll) { clearInterval(state.jobPoll); state.jobPoll = null; }
    if (state.jobGuard) { clearTimeout(state.jobGuard); state.jobGuard = null; }
  }
  var pollBusy = false;
  async function pollOnce() {
    if (pollBusy || !state.job || !state.running) return;
    pollBusy = true;
    try {
      var r = await Bridge.exec(buildPollCommand(state.job, state.jobOffset), {});
      var p = String(r.stdout || '').split('|');
      if (p.length < 4) return;
      var rem = parseInt(p[0], 10) || 0;
      var raw = b64ToBytes(p[1]);
      var bytes = rem ? raw.subarray(Math.min(rem, raw.length)) : raw;
      state.jobOffset += bytes.length;
      if (bytes.length) pushChunk(decodeChunk(bytes, false), '');
      var sz = parseInt(p[3], 10) || 0;
      setTermMeta('守护执行中 · ' + state.jobOffset + '/' + sz + ' B · 清理 App 不影响');
      var done = p[2] !== '-' && p[2] !== '';
      if (done && state.jobOffset >= sz) {
        flushChunk();
        var tail = decodeChunk(new Uint8Array(0), true);
        if (tail) pushChunk(tail, '');
        var rc = parseInt(p[2], 10);
        if (isNaN(rc)) rc = 0;
        stopPolling();
        finish(rc, state.jobT0);
      }
    } catch (e) {
      // 单次轮询失败不中断，等下一轮
    } finally {
      pollBusy = false;
    }
  }
  function startPolling() {
    stopPolling();
    state.jobPoll = setInterval(pollOnce, POLL_MS);
    state.jobGuard = setTimeout(function () {
      if (state.running && state.mode === 'background' && state.job) {
        stopPolling();
        appendTerm('⚠ 轮询超时；作业可能仍在后台运行，重开页面会自动续看', 'sys');
        state.running = false;
        setBadge('fail', 'TIMEOUT');
        $('#runBtn').disabled = false;
        $('#stopBtn').hidden = true;
      }
    }, 600000);
    pollOnce();
  }

  async function stopJob() {
    if (!state.job) return;
    // runner 的 $$ 是父进程，脚本是它的子进程；必须一起杀，否则脚本会继续跑
    var cmd = 'J=' + q(state.job) + '; p=$(cat "$J/pid" 2>/dev/null); ' +
      'if [ -n "$p" ]; then ' +
        'for d in /proc/[0-9]*; do c=${d##*/}; ' +
          'pp=$(sed -n ' + q('s/^PPid:[[:space:]]*//p') + ' "$d/status" 2>/dev/null | head -n 1); ' +
          '[ "$pp" = "$p" ] && kill -9 "$c" 2>/dev/null; ' +
        'done; kill -9 "$p" 2>/dev/null; ' +
      'fi; printf 137 > "$J/done"; printf __STOPPED__';
    await Bridge.exec(cmd, {});
  }

  // 页面重开（管理器被清理后再进入）时，从 current.job 恢复进度
  async function tryResumeJob() {
    if (state.running) return;
    try {
      var r = await Bridge.exec('cat ' + q(JOB_ROOT + '/current.job') + ' 2>/dev/null', {});
      var j = String(r.stdout || '').trim();
      // current.job 里存的是完整作业目录路径，不是裸 id
      if (j.indexOf(JOBS_DIR + '/job_') !== 0 || !/^[A-Za-z0-9_/-]+$/.test(j)) return;
      var chk = await Bridge.exec('[ -d ' + q(j) + ' ] && printf ok', {});
      if (String(chk.stdout || '').indexOf('ok') < 0) return;
      var d = await Bridge.exec('if [ -f ' + q(j + '/done') + ' ]; then printf d; else printf r; fi', {});
      var ended = String(d.stdout || '').indexOf('d') >= 0;
      if (ended) {
        var stale = await Bridge.exec('find ' + q(j + '/done') + ' -mmin +5 2>/dev/null', {});
        if (String(stale.stdout || '').trim()) return;
      }

      state.job = j;
      state.mode = 'background';
      state.jobOffset = 0;
      state.jobDecoder = newDecoder();
      state.jobT0 = performance.now();
      state.running = true;
      state.streamBuf = ''; state.streamCls = '';
      clearTerm();
      appendTerm('$ 恢复后台作业', 'cmd');
      appendTerm(ended ? '▸ 上次作业已结束，正在读取完整输出' : '▸ 管理器曾被清理，作业一直在后台运行', 'sys');
      appendTerm('──────────────────────────────', 'muted');
      setBadge(ended ? 'ok' : 'running', ended ? 'READING' : 'RUNNING');
      setTermMeta('恢复中…');
      $('#runBtn').disabled = true;
      $('#stopBtn').hidden = ended;
      stopPolling();
      pollOnce();
      if (!ended) startPolling();
      else {
        // 已结束：把剩余输出一次性读完
        var guard = 0;
        var readAll = async function () {
          while (state.running && guard++ < 40) {
            var before = state.jobOffset;
            await pollOnce();
            if (!state.running || state.jobOffset === before) break;
          }
          if (state.running) finish(0, state.jobT0);
        };
        readAll();
      }
    } catch (e) { }
  }

  /* ---------------- 执行 ---------------- */
  function startInteractive() {
    state.interactive = true;
    $('#termInput').hidden = false;
    $('#termHint').hidden = false;
    appendTerm('▸ 实时输入已启用 · 脚本提示出现后可在下方输入', 'sys');
  }
  function endInteractive() {
    if (!state.interactive) return;
    state.interactive = false;
    try {
      if (Bridge.child && Bridge.child.stdin && typeof Bridge.child.stdin.end === 'function') {
        Bridge.child.stdin.end();
      }
    } catch (e) { }
    $('#termInput').hidden = true;
    $('#termHint').hidden = true;
    appendTerm('▸ 输入通道已关闭 (EOF)', 'sys');
  }
  function sendInteractive() {
    if (!state.running || !state.interactive) return;
    var el = $('#tiText');
    var v = el.value;
    if (!v) return;
    try {
      Bridge.child.stdin.write(v + '\n');
      appendTerm('$ > ••••••', 'cmd');
      el.value = '';
      el.focus();
    } catch (e) {
      showToast('写入失败：' + e.message, 'err');
    }
  }

  function finish(code, t0) {
    if (!state.running) return;
    state.running = false;
    state.interactive = false;
    stopPolling();
    $('#termInput').hidden = true;
    $('#termHint').hidden = true;
    $('#stopBtn').hidden = true;
    Bridge.child = null;
    Bridge.canWriteStdin = false;
    flushChunk();
    var sec = ((performance.now() - t0) / 1000).toFixed(2);
    setBadge(code === 0 ? 'ok' : 'fail', code === 0 ? 'EXIT 0' : 'EXIT ' + code);
    setTermMeta('退出码 ' + code + ' · 耗时 ' + sec + 's · ' + nowTime());
    appendTerm('', '');
    if (state.job && state.mode === 'background') {
      appendTerm('▸ 后台作业已结束 · 输出保存在本机，可复制留存', 'sys');
    }
    appendTerm(code === 0 ? '✓ 执行完成 (exit 0)' : '✗ 脚本结束 (exit ' + code + ')', code === 0 ? 'ok' : 'err');
    $('#runBtn').disabled = false;
    showToast(code === 0 ? '脚本执行完成' : '脚本退出码 ' + code, code === 0 ? 'ok' : 'err');
  }

  async function doRun() {
    if (!state.selected || state.running) return;
    var vals = state.inputEnabled ? collectInputs() : [];
    var needInputs = !!(state.detected && state.detected.reads > 0);
    if (needInputs && !vals.length) {
      showToast('脚本需要输入，可在上方「脚本输入 / 卡密」预填', 'err');
    }
    await closeConfirm();
    var path = joinPath(state.dir, state.selected.name);
    var name = state.selected.name;
    state.rcTranslated = false;

    // .rc 走转译：把生成的 sh 写到临时文件，后续执行通道完全复用
    if (state.parseKind === 'initrc') {
      var sh = state.translatedSh || translateInitRc(state.scriptText || '').sh;
      if (!sh.trim()) { showToast('转译结果为空，请检查脚本内容', 'err'); return; }
      var tmp = JOB_ROOT + '/translated/' + makeJobId() + '.sh';
      var ok = await writeTranslated(tmp, sh);
      if (!ok) {
        appendTerm('✗ .rc 转译脚本写入失败，任务未执行', 'err');
        setBadge('fail', 'TRANS FAIL');
        setTermMeta('转译失败');
        showToast('转译脚本写入失败', 'err');
        return;
      }
      path = tmp;
      state.rcTranslated = true;
    }

    if (state.mode === 'background') return runBackground(path, name, vals);
    return runForeground(path, name, vals, needInputs);
  }

  // 默认路径：任务交给 ksud 派生的 watchdog，脚本完全不在 App 进程树里
  async function runBackground(path, name, vals) {
    state.mode = 'background';

    // 守护不在线时绝不能直接投递：卡密会卡在无名管道里，App 一被清理就丢
    var online = await checkDaemon();
    if (!online) {
      showToast('系统守护未运行：请点「拉起守护」或重启一次设备', 'err');
      appendTerm('✗ 系统守护未运行，任务未提交', 'err');
      appendTerm('▸ 模块更新后需重启一次，service.sh 才会由 ksud 拉起守护', 'sys');
      appendTerm('▸ 也可点终端面板的「拉起守护」立即启动', 'sys');
      setBadge('fail', 'NO DAEMON');
      setTermMeta('等待守护进程');
      return;
    }

    var job = JOBS_DIR + '/' + makeJobId();
    state.job = job;
    state.jobOffset = 0;
    state.jobDecoder = newDecoder();
    state.jobT0 = performance.now();
    state.running = true;
    state.interactive = false;
    stopPolling();

    clearTerm();
    appendTerm('$ sh ' + name + (vals.length ? '  ← ' + vals.length + ' 项输入' : ''), 'cmd');
    appendTerm('▸ 已投递到系统守护 · ' + nowTime() + ' · PID ' + state.daemonPid, 'sys');
    appendTerm('▸ 脚本由 ksud 派生的守护执行，不在管理器 App 进程树里', 'ok');
    if (state.rcTranslated) appendTerm('▸ .rc 已转译为 Shell 动作后执行（init 触发语义不生效）', 'sys');
    if (vals.length) appendTerm('▸ ' + vals.length + ' 项输入经 FIFO 内核缓冲传入，不落盘', 'sys');
    appendTerm('──────────────────────────────', 'muted');
    setBadge('running', 'RUNNING');
    setTermMeta('正在投递任务…');
    $('#runBtn').disabled = true;
    $('#stopBtn').hidden = false;
    await nextFrame();

    try {
      var ok = await ensureRunner();
      if (!ok) throw new Error('无法准备后台执行器');
      var r = await Bridge.exec(buildSubmitCommand(path, vals, job), {});
      var out = String(r.stdout || '');
      if (out.indexOf('__NO_DAEMON__') >= 0) throw new Error('守护未认领任务（可能刚被系统回收）');
      if (out.indexOf('__FIFO_FAIL__') >= 0) throw new Error('无法创建输入管道');
      if (out.indexOf('__SUBMITTED__') < 0) throw new Error('作业提交失败');
      setTermMeta('守护执行中 · 清理 KSU 后台不影响');
      startPolling();
    } catch (e) {
      // 不静默回退到「跟随界面」——那会让脚本再次随 App 一起死，正是要避开的坑
      appendTerm('✗ ' + e.message, 'err');
      appendTerm('▸ 任务未提交，脚本没有运行；请点「拉起守护」后重试', 'sys');
      state.running = false;
      state.job = null;
      stopPolling();
      $('#runBtn').disabled = false;
      $('#stopBtn').hidden = true;
      setBadge('fail', 'SUBMIT FAIL');
      setTermMeta('提交失败 · 等待守护');
      checkDaemon();
    }
  }

  // 旧行为：绑定 WebView 生命周期，好处是支持运行时实时 stdin 输入
  async function runForeground(path, name, vals, needInputs) {
    state.running = true;
    var t0 = performance.now();
    var finished = false;

    clearTerm();
    appendTerm('$ sh ' + name + (vals.length ? '  ← ' + vals.length + ' 项输入' : ''), 'cmd');
    appendTerm('▸ root 执行 · ' + nowTime() + ' · ' + state.channel.toUpperCase(), 'sys');
    if (state.rcTranslated) appendTerm('▸ .rc 已转译为 Shell 动作后执行（init 触发语义不生效）', 'sys');
    if (vals.length) appendTerm('▸ 已注入 ' + vals.length + ' 项输入（内容已隐藏）', 'sys');
    appendTerm('──────────────────────────────', 'muted');
    setBadge('running', 'RUNNING');
    setTermMeta(vals.length ? '执行中 · 已注入输入' : '执行中…');
    $('#runBtn').disabled = true;
    state.interactive = false;
    state.streamBuf = ''; state.streamCls = '';
    await nextFrame();

    var once = function (code) {
      if (finished) return;
      finished = true;
      finish(code, t0);
    };
    // 兜底：流式回调异常时不要永远卡在「执行中」
    var guard = setTimeout(function () { endInteractive(); once(-1); }, 180000);

    var handlers = {
      out: function (d) { pushChunk(d, ''); },
      err: function (d) { pushChunk(d, 'err'); },
      exit: function (c) { clearTimeout(guard); once(c); }
    };

    // 预填了输入 → 走 exec 一次性注入 stdin（最稳，覆盖 read / $1 / 环境变量）
    // 未预填 → 尝试 spawn 流式；若管理器提供 stdin.write，则升级为实时对话
    var used = false;
    if (!vals.length) {
      used = Bridge.spawn('sh', [path], handlers, {});
      if (used && Bridge.canWriteStdin) {
        startInteractive();
      } else if (used && needInputs) {
        appendTerm('⚠ 管理器未提供实时 stdin，建议回到确认页预填输入', 'err');
      }
    }

    if (!used) {
      try {
        var r = await Bridge.exec(buildRunCommand(path, vals), {});
        if (r.stdout) typeLines(r.stdout);
        if (r.stderr) appendTerm(r.stderr, 'err');
        clearTimeout(guard);
        once(r.errno || 0);
      } catch (e) {
        appendTerm('✗ ' + e.message, 'err');
        clearTimeout(guard);
        once(-1);
      }
    }
  }

  /* ---------------- 导入脚本 ---------------- */
  async function importFile(file) {
    if (!file) return;
    if (file.size > 512 * 1024) { showToast('脚本过大（上限 512 KB）', 'err'); return; }
    var name = String(file.name).replace(/[^A-Za-z0-9._-]/g, '_').replace(/\.\.+/g, '_');
    if (!/\.(sh|rc)$/i.test(name)) name += '.sh';
    if (name.length > 60) name = name.slice(-60);
    showToast('正在导入 ' + name + '…');
    try {
      var bytes = new Uint8Array(await file.arrayBuffer());
      var bin = '';
      for (var i = 0; i < bytes.length; i += 0x8000) {
        bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      }
      var b64 = btoa(bin);
      var target = joinPath(state.dir, name);
      var cmd = 'mkdir -p ' + q(state.dir) + ' && printf %s ' + q(b64) +
        ' | base64 -d > ' + q(target) + ' && chmod 644 ' + q(target) + ' && printf __IMPORT_OK__';
      var r = await Bridge.exec(cmd, {});
      if (String(r.stdout || '').indexOf('__IMPORT_OK__') >= 0) {
        showToast('已导入 ' + name, 'ok');
        Bridge.toast('脚本已导入');
        await scan();
      } else {
        showToast('导入失败，请手动把 .sh 放进目录', 'err');
      }
    } catch (e) {
      showToast('导入失败：' + e.message, 'err');
    }
  }

  /* ---------------- 事件绑定 ---------------- */
  function bind() {
    $('#scriptList').addEventListener('click', function (e) {
      var item = e.target.closest('.script-item');
      if (!item) return;
      var name = item.dataset.name;
      if (state.selected && state.selected.name === name) {
        openConfirm();
      } else {
        selectByName(name);
      }
    });

    $('#runBtn').addEventListener('click', openConfirm);
    $('#refreshBtn').addEventListener('click', function () { scan(); });
    $('#goBtn').addEventListener('click', function () {
      var v = $('#dirInput').value.trim();
      if (!v) { showToast('请输入目录路径', 'err'); return; }
      state.dir = v.replace(/\/+$/, '');
      renderChips(state.existing);
      scan();
    });
    $('#dirInput').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); $('#goBtn').click(); }
    });

    $('#importBtn').addEventListener('click', function () { $('#fileInput').click(); });
    $('#emptyImportBtn').addEventListener('click', function () { $('#fileInput').click(); });
    $('#fileInput').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0];
      importFile(f);
      e.target.value = '';
    });

    $('#copyBtn').addEventListener('click', function () {
      var text = state.logLines.join('\n').trim();
      if (!text) { showToast('暂无输出可复制', 'err'); return; }
      copyText(text);
    });
    $('#clearBtn').addEventListener('click', function () {
      if (state.running) { showToast('执行中，暂不清空', 'err'); return; }
      clearTerm(); setBadge('', 'IDLE'); setTermMeta('等待执行');
      appendTerm('$ 等待选择脚本…', 'muted');
    });

    // 卡密库
    var vaultFromConfirm = false;
    function showVault(fromConfirm) {
      vaultFromConfirm = !!fromConfirm;
      openVault();
    }
    $('#vaultBtn').addEventListener('click', function () { showVault(false); });
    $('#openVaultBtn').addEventListener('click', function () { showVault(true); });
    $('#unlockHereBtn').addEventListener('click', function () { showVault(true); });
    $('#vaultMask').addEventListener('click', closeVault);
    $('#vaultCloseBtn').addEventListener('click', closeVault);
    $('#vaultUnlockBtn').addEventListener('click', async function () {
      var pass = $('#vaultPass').value;
      if (!pass) { $('#vaultErr').textContent = '请输入保管口令'; $('#vaultErr').hidden = false; return; }
      var ok = await Vault.unlock(pass);
      if (!ok) {
        $('#vaultErr').textContent = '口令不对，或卡密库数据已损坏';
        $('#vaultErr').hidden = false;
        return;
      }
      $('#vaultErr').hidden = true;
      renderVaultUI();
      showToast('卡密库已解锁', 'ok');
      if (vaultFromConfirm) { vaultFromConfirm = false; closeVault(); }
    });
    $('#vaultPass').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); $('#vaultUnlockBtn').click(); }
    });
    $('#vaultForgetBtn').addEventListener('click', function () {
      var n = Vault.count();
      openDanger({
        title: '清除全部并重置口令？',
        desc: '忘记口令后无法找回已存卡密，只能清空后重新填写。',
        details: [
          '将永久删除 ' + n + ' 份已保存的卡密',
          '保管口令会一并移除，下次打开无需解锁'
        ],
        ok: '清除并重置',
        action: async function () {
          await Vault.forgetAndReset();
          renderVaultUI();
          resetRememberUI();
          showToast('已清除全部卡密并重置口令', 'ok');
        }
      });
    });
    $('#vaultSetPassBtn').addEventListener('click', async function () {
      var pass = $('#vaultNewPass').value;
      var ok = await Vault.setPassphrase(pass);
      if (!ok) { showToast('设置失败：卡密库数据异常', 'err'); return; }
      renderVaultUI();
      showToast(pass ? '保管口令已设置' : '已取消保管口令', 'ok');
    });
    $('#vaultRemovePassBtn').addEventListener('click', async function () {
      var ok = await Vault.setPassphrase('');
      if (!ok) { showToast('取消失败', 'err'); return; }
      renderVaultUI();
      showToast('已取消保管口令', 'ok');
    });
    $('#vaultClearBtn').addEventListener('click', function () {
      var n = Vault.count();
      if (!n) { showToast('卡密库已经是空的', 'err'); return; }
      var withPass = Vault.mode() === 'pass';
      var details = ['将永久删除 ' + n + ' 份已保存的卡密', '各脚本下次打开需重新填写'];
      if (withPass) details.push('保管口令也会一并移除');
      openDanger({
        title: '清除全部卡密？',
        desc: '这会删掉所有脚本记住的卡密，无法撤销。',
        details: details,
        ok: '确认清除',
        action: async function () {
          await Vault.clear();
          renderVaultUI();
          resetRememberUI();
          showToast('已清除全部已存卡密', 'ok');
        }
      });
    });

    // 二次确认弹窗：只有「确认清除」会执行上面暂存的动作
    $('#dangerCancelBtn').addEventListener('click', closeDanger);
    $('#dangerMask').addEventListener('click', closeDanger);
    $('#dangerOkBtn').addEventListener('click', async function () {
      var fn = dangerAction;
      closeDanger();
      if (fn) { try { await fn(); } catch (e) { showToast('操作失败：' + e.message, 'err'); } }
    });

    function resetRememberUI() {
      // 内存里的输入值也要清掉，避免下次打开确认页时残留
      state.inputs = [];
      if ($('#confirmModal').hidden) return;
      $('#rememberCheck').checked = false;
      $('#rememberHint').textContent = '勾一次，以后打开自动填好';
      $('#vaultLockHint').hidden = true;
    }
    $('#rememberCheck').addEventListener('change', function (e) {
      if (Vault.isLocked() && e.target.checked) {
        e.target.checked = false;
        showToast('卡密库已锁定，请先解锁', 'err');
        showVault(true);
        return;
      }
      $('#rememberHint').textContent = e.target.checked
        ? '关闭确认页后保存，下次自动填好'
        : '勾一次，以后打开自动填好';
    });
    Vault.onUnlock(function () {
      if (!$('#confirmModal').hidden) applyVaultFill();
    });

    $('#agreeCheck').addEventListener('change', function (e) {
      $('#confirmBtn').disabled = !e.target.checked;
    });
    document.querySelectorAll('input[name="parseKind"]').forEach(function (el) {
      el.addEventListener('change', function () {
        if (!el.checked) return;
        state.parseKind = el.value;
        document.querySelectorAll('.parse-opt').forEach(function (o) {
          o.classList.toggle('active', o.querySelector('input').checked);
        });
        renderTranslation();
      });
    });
    document.querySelectorAll('input[name="runMode"]').forEach(function (el) {
      el.addEventListener('change', function () {
        if (!el.checked) return;
        state.mode = el.value;
        document.querySelectorAll('.mode-opt').forEach(function (o) {
          o.classList.toggle('active', o.querySelector('input').checked);
        });
      });
    });
    $('#daemonBtn').addEventListener('click', bootDaemon);
    $('#stopBtn').addEventListener('click', async function () {
      if (!state.job || !state.running) return;
      showToast('正在终止后台作业…');
      try { await stopJob(); } catch (e) { }
      // 正常由轮询读到 done=137 收尾；轮询若已停则兜底
      setTimeout(function () {
        if (state.running && state.mode === 'background') {
          stopPolling();
          finish(137, state.jobT0);
        }
      }, 1800);
    });
    $('#cancelBtn').addEventListener('click', closeConfirm);
    $('#modalMask').addEventListener('click', closeConfirm);
    $('#cfCopy').addEventListener('click', function () { copyText($('#cfPath').textContent); });
    $('#confirmBtn').addEventListener('click', function () {
      if ($('#agreeCheck').checked) doRun();
    });

    // 脚本输入 / 卡密
    $('#inputToggle').addEventListener('change', function (e) { setInputEnabled(e.target.checked); });
    $('#addRow').addEventListener('click', function () {
      var cur = collectInputs();
      state.inputs = cur;
      renderInputRows(cur.length + 1);
    });
    // 按键时只写对应索引，不做 querySelectorAll / 不重建任何 DOM
    $('#inputRows').addEventListener('input', function (e) {
      var el = e.target;
      if (!el || el.tagName !== 'INPUT') return;
      var i = Number(el.dataset.idx);
      if (!isNaN(i)) state.inputs[i] = String(el.value).replace(/[\r\n]+/g, ' ');
    });
    $('#inputRows').addEventListener('click', function (e) {
      var btn = e.target.closest('button');
      if (!btn) return;
      var row = btn.closest('.input-row');
      var rows = Array.prototype.slice.call($('#inputRows').children);
      var i = rows.indexOf(row);
      if (btn.classList.contains('eye')) {
        var inp = row.querySelector('input');
        inp.type = inp.type === 'password' ? 'text' : 'password';
        btn.classList.toggle('on');
      } else if (btn.classList.contains('del')) {
        var cur = collectInputs();
        if (cur.length <= 1) { showToast('至少保留一行输入', 'err'); return; }
        cur.splice(i, 1);
        state.inputs = cur;
        renderInputRows(cur.length);
      }
    });

    // 实时交互输入条
    $('#tiSend').addEventListener('click', sendInteractive);
    $('#tiText').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); sendInteractive(); }
    });
    $('#tiEye').addEventListener('click', function () {
      var el = $('#tiText');
      el.type = el.type === 'password' ? 'text' : 'password';
      $('#tiEye').classList.toggle('on');
    });
    $('#tiEof').addEventListener('click', endInteractive);

    // 键盘弹出 / 打字期间，暂停背景装饰动画，把合成资源全留给输入框
    document.addEventListener('focusin', function (e) {
      if (e.target && /^(INPUT|TEXTAREA)$/.test(e.target.tagName)) {
        document.body.classList.add('typing');
      }
    });
    document.addEventListener('focusout', function (e) {
      if (e.target && /^(INPUT|TEXTAREA)$/.test(e.target.tagName)) {
        document.body.classList.remove('typing');
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (!$('#dangerModal').hidden) { closeDanger(); return; }
      if (!$('#vaultModal').hidden) { closeVault(); return; }
      if (!$('#confirmModal').hidden) closeConfirm();
    });
  }

  /* ---------------- 演示场景（仅浏览器预览用） ---------------- */
  function demoOutput() {
    clearTerm();
    appendTerm('$ sh 00_hello.sh', 'cmd');
    appendTerm('▸ root 执行 · ' + nowTime() + ' · ESM', 'sys');
    appendTerm('──────────────────────────────', 'muted');
    DEMO_OUTPUT.split('\n').forEach(function (l) { appendTerm(l, ''); });
    appendTerm('', '');
    appendTerm('✓ 执行完成 (exit 0)', 'ok');
    setBadge('ok', 'EXIT 0');
    setTermMeta('退出码 0 · 耗时 0.08s · ' + nowTime());
  }

  /* ---------------- 启动 ---------------- */
  async function init() {
    bind();
    try { await Vault.init(); } catch (e) { }
    renderVaultBadge();
    if (Vault.isLocked() && Vault.count()) {
      setTimeout(function () { showToast('卡密库已锁定，点「卡密库」输入口令解锁'); }, 900);
    }
    $('#dirInput').value = state.dir;

    if (FORCE_DEMO) {
      Bridge.channel = 'preview';
    } else {
      try { await Bridge.probe(); } catch (e) { Bridge.channel = 'preview'; }
    }
    state.channel = Bridge.channel;

    var pill = $('#statusPill');
    if (Bridge.channel === 'preview') {
      pill.className = 'status-pill preview';
      $('#statusText').textContent = '预览模式';
      $('#metaText').textContent = '预览模式 · 演示数据（需在 KSU 管理器中打开以执行）';
    } else {
      pill.className = 'status-pill ready';
      $('#statusText').textContent = 'ROOT 已连接';
      $('#metaText').textContent = '通道 ' + Bridge.channel.toUpperCase();
    }

    // 探测哪些候选目录真实存在
    var existing = [];
    try {
      var r = await Bridge.exec('for d in ' + CANDIDATE_DIRS.map(q).join(' ') + '; do [ -d "$d" ] && printf "%s\\n" "$d"; done');
      existing = String(r.stdout || '').split('\n').filter(Boolean);
    } catch (e) { }
    if (!FORCE_DEMO && existing.length && existing.indexOf(state.dir) < 0) {
      state.dir = existing[0];
      $('#dirInput').value = state.dir;
    }
    state.existing = existing.length ? existing : CANDIDATE_DIRS.slice(0, 3);
    renderChips(state.existing);
    await scan();

    if ((DEMO_SCENE === 'rc' || DEMO_SCENE === 'confirm') && state.scripts.length) {
      var pick = DEMO_SCENE === 'rc'
        ? (state.scripts.some(function (s) { return s.name === '04_init_rc_demo.rc'; })
            ? '04_init_rc_demo.rc' : state.scripts[0].name)
        : (state.scripts.some(function (s) { return s.name === '03_card_key_demo.sh'; })
            ? '03_card_key_demo.sh' : state.scripts[0].name);
      selectByName(pick);
      openConfirm();
    } else if (DEMO_SCENE === 'output') {
      if (state.scripts.length) selectByName(state.scripts[0].name);
      demoOutput();
    } else if (DEMO_SCENE === 'select') {
      if (state.scripts.length) selectByName(state.scripts[0].name);
    } else if (DEMO_SCENE === 'interactive') {
      if (state.scripts.length) {
        var k = state.scripts.some(function (s) { return s.name === '03_card_key_demo.sh'; })
          ? '03_card_key_demo.sh' : state.scripts[0].name;
        selectByName(k);
      }
      clearTerm();
      appendTerm('$ sh 03_card_key_demo.sh', 'cmd');
      appendTerm('▸ root 执行 · ' + nowTime() + ' · ' + state.channel.toUpperCase(), 'sys');
      appendTerm('▸ 实时输入已启用 · 脚本提示出现后可在下方输入', 'sys');
      appendTerm('──────────────────────────────', 'muted');
      appendTerm('请输入卡密: ', '');
      appendTerm('$ > ••••••', 'cmd');
      appendTerm('请再次确认 (y/n): ', '');
      appendTerm('$ > ••••••', 'cmd');
      appendTerm('✓ 三种通道都拿到输入了（内容不回显）', 'ok');
      setBadge('ok', 'EXIT 0');
      setTermMeta('退出码 0 · 实时交互演示');
      $('#termInput').hidden = false;
      $('#termHint').hidden = false;
    } else if (DEMO_SCENE === 'background') {
      if (state.scripts.length) selectByName(state.scripts[0].name);
      clearTerm();
      appendTerm('$ sh 00_hello.sh  ← 2 项输入', 'cmd');
      appendTerm('▸ 已投递到系统守护 · ' + nowTime() + ' · PID 2184', 'sys');
      appendTerm('▸ 脚本由 ksud 派生的守护执行，不在管理器 App 进程树里', 'ok');
      appendTerm('▸ 2 项输入经 FIFO 内核缓冲传入，不落盘', 'sys');
      appendTerm('──────────────────────────────', 'muted');
      DEMO_OUTPUT.split('\n').forEach(function (l) { appendTerm(l, ''); });
      appendTerm('', '');
      appendTerm('✓ 执行完成 (exit 0)', 'ok');
      setBadge('ok', 'EXIT 0');
      setTermMeta('退出码 0 · 守护执行完成');
    }

    // 预览图用：把守护状态条渲染成「在线」的视觉效果
    if (FORCE_DEMO && (DEMO_SCENE === 'background' || DEMO_SCENE === 'daemon')) {
      $('#daemonBar').className = 'daemon-bar online';
      $('#daemonText').textContent = '系统守护在线 · PID 2184 · 清理 App 不影响脚本';
      $('#daemonBtn').hidden = true;
    }

    // 守护状态：启动即查，之后每 8 秒轻量刷新（只读一个时间戳文件）
    if (Bridge.channel === 'preview') {
      if (!(FORCE_DEMO && (DEMO_SCENE === 'background' || DEMO_SCENE === 'daemon'))) {
        renderDaemonBar();
      }
    } else {
      await checkDaemon();
      setInterval(function () { if (!document.hidden) checkDaemon(); }, 8000);
      // 管理器被清理后重开 WebUI：从 current.job 把后台任务接回来
      tryResumeJob();
    }
  }

  init();
})();

package com.dianxia.swapterminal

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#080b11")
        window.navigationBarColor = Color.parseColor("#080b11")

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#080b11"))
        setContentView(web, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true          // 卡密库依赖 localStorage
        s.allowFileAccess = true
        s.allowContentAccess = true
        s.setSupportZoom(false)
        s.textZoom = 100
        s.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        WebView.setWebContentsDebuggingEnabled(false)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, url: String): Boolean {
                // 全离线：只允许 assets 内部跳转，外部链接一律拦下
                return !url.startsWith("file:///android_asset/")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                v: WebView,
                cb: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                val callback = cb ?: return false
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    startActivityForResult(Intent.createChooser(i, "选择脚本"), REQ_FILE)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        // 注入与 KernelSU WebUI 同形状的 window.ksu 接口
        web.addJavascriptInterface(KsuJsApi(this, web), "ksu")
        web.loadUrl("file:///android_asset/webroot/index.html")

        // 首次启动铺好 root 侧守护脚本，并拉起守护（与 App 进程解耦）
        Thread {
            RootExec.installRuntime(applicationContext)
            RootExec.ensureDaemon()
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FILE) return
        val cb = filePathCallback
        filePathCallback = null
        if (cb == null) return
        val uri = if (resultCode == RESULT_OK) data?.data else null
        cb.onReceiveValue(if (uri != null) arrayOf(uri) else null)
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    companion object {
        private const val REQ_FILE = 1001
    }
}

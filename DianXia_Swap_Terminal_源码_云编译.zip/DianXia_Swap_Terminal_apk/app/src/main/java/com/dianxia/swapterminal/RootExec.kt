package com.dianxia.swapterminal

import android.content.Context
import android.util.Base64

/** root 侧执行与守护铺设。所有命令都走 su -c，App 本身不需要任何系统权限。 */
object RootExec {

    const val ROOT = "/data/local/tmp/DianXia_Swap_Terminal"
    private val APK = ROOT + "/apk"
    private val JOBS = ROOT + "/jobs"
    private val SCRIPTS = ROOT + "/scripts"

    data class Result(val errno: Int, val stdout: String, val stderr: String)

    private fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    fun run(command: String): Result {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            var out = ""
            var err = ""
            val tOut = Thread {
                try { out = String(p.inputStream.readBytes(), Charsets.UTF_8) } catch (e: Exception) { }
            }
            val tErr = Thread {
                try { err = String(p.errorStream.readBytes(), Charsets.UTF_8) } catch (e: Exception) { }
            }
            tOut.start(); tErr.start()

            var code = 127
            val deadline = System.currentTimeMillis() + 180_000L
            while (true) {
                try { code = p.exitValue(); break } catch (e: IllegalThreadStateException) { }
                if (System.currentTimeMillis() > deadline) {
                    p.destroy()
                    err += "\n[交换终端] 命令超时（180s）已终止"
                    code = 124
                    break
                }
                Thread.sleep(50)
            }
            tOut.join(2000); tErr.join(2000)
            Result(code, out, err)
        } catch (e: Exception) {
            Result(127, "", "root 执行失败：${e.message}\n请确认设备已 root，并在 KernelSU / Magisk 里授予本应用 su 权限。")
        }
    }

    /** 把 assets 里的守护脚本铺到 root 可读目录，WebUI 的 ensureRunner 随后会接管 */
    fun installRuntime(ctx: Context) {
        run("mkdir -p " + q(APK) + " " + q(JOBS) + " " + q(SCRIPTS) +
            "; chmod 700 " + q(ROOT) + " " + q(APK) + " " + q(JOBS) + " 2>/dev/null")
        for (name in arrayOf("runner.sh", "watchdog.sh")) {
            val dest = APK + "/" + name
            push(ctx, "scripts/" + name, dest)
            push(ctx, "scripts/" + name, ROOT + "/" + name)
        }
        run("chmod 755 " + q(APK + "/runner.sh") + " " + q(APK + "/watchdog.sh") +
            " " + q(ROOT + "/runner.sh") + " " + q(ROOT + "/watchdog.sh") + " 2>/dev/null")

        // 目录为空时放入内置示例；用户已经有脚本就一个都不动
        val hasAny = run("ls " + q(SCRIPTS) + " 2>/dev/null | head -n 1").stdout.trim().isNotEmpty()
        if (!hasAny) {
            val demos = try { ctx.assets.list("scripts/demo") } catch (e: Exception) { null }
            if (demos != null) {
                for (name in demos) {
                    if (name.endsWith(".sh") || name.endsWith(".rc")) {
                        push(ctx, "scripts/demo/" + name, SCRIPTS + "/" + name)
                    }
                }
            }
        }
    }

    /** 用 base64 通过命令行传递，不依赖 su 是否转发 stdin */
    private fun push(ctx: Context, assetPath: String, dest: String) {
        try {
            val bytes = ctx.assets.open(assetPath).use { it.readBytes() }
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            run("printf %s " + q(b64) + " | base64 -d > " + q(dest) +
                " && chmod 644 " + q(dest))
        } catch (e: Exception) { }
    }

    /**
     * setsid 让守护脱离 App 与 su 的会话；父进程最终是 init / ksud。
     * 划掉最近任务、强制停止 App 都不会波及它。watchdog.sh 自带单实例检查。
     */
    fun ensureDaemon() {
        run("mkdir -p " + q(JOBS) + "; " +
            "nohup setsid sh " + q(ROOT + "/watchdog.sh") +
            " >/dev/null 2>&1 </dev/null & printf started")
    }
}

package com.dianxia.swapterminal

import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.util.concurrent.Executors

/**
 * 给 WebUI 注入 window.ksu，形状与 KernelSU 管理器一致：
 *   ksu.exec(cmd, optsJson, callbackName) -> window[callbackName](errno, stdout, stderr)
 *   ksu.toast(msg)
 *
 * 命令一律在后台线程由 root shell 执行；结果回主线程用 evaluateJavascript 回调，
 * 不阻塞 UI。marker 探测命令直接短路返回，避免首次 su 授权超过 WebUI 的 3.5s 探测窗口。
 */
class KsuJsApi(private val activity: MainActivity, private val web: WebView) {

    private val pool = Executors.newCachedThreadPool()

    @JavascriptInterface
    fun exec(cmd: String?, opts: String?, cb: String?) {
        val command = cmd ?: return
        if (command.contains(MARKER)) {
            reply(cb, 0, MARKER, "")
            return
        }
        pool.execute {
            val r = RootExec.run(command)
            reply(cb, r.errno, r.stdout, r.stderr)
        }
    }

    @JavascriptInterface
    fun toast(msg: String?) {
        if (msg.isNullOrEmpty()) return
        activity.toast(msg)
    }

    private fun reply(cb: String?, errno: Int, out: String, err: String) {
        if (cb.isNullOrEmpty()) return
        val js = "(function(){try{var f=window[" + quote(cb) + "];" +
            "if(typeof f==='function'){f(" + errno + "," + quote(out) + "," + quote(err) + ");}" +
            "}catch(e){}})()"
        web.post { web.evaluateJavascript(js, null) }
    }

    /** JSON 字符串字面量，顺带处理 JS 里会截断脚本的 U+2028/2029 与控制字符 */
    private fun quote(s: String): String {
        val b = StringBuilder("\"")
        for (c in s) {
            when {
                c == '"' -> b.append("\\\"")
                c == '\\' -> b.append("\\\\")
                c == '\n' -> b.append("\\n")
                c == '\r' -> b.append("\\r")
                c == '\t' -> b.append("\\t")
                c == '\b' -> b.append("\\b")
                c.code == 0x2028 -> b.append("\\u2028")
                c.code == 0x2029 -> b.append("\\u2029")
                c.code < 0x20 -> b.append("\\u" + c.code.toString(16).padStart(4, '0'))
                else -> b.append(c)
            }
        }
        return b.append("\"").toString()
    }

    companion object {
        private const val MARKER = "__DIANXIA_SWAP_TERMINAL_OK__"
    }
}

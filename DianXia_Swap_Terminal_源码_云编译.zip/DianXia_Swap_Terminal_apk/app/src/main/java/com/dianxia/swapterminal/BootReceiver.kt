package com.dianxia.swapterminal

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        Thread {
            try {
                RootExec.installRuntime(context.applicationContext)
                RootExec.ensureDaemon()
            } finally {
                pending.finish()
            }
        }.start()
    }
}

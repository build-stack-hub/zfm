# DianXia_Swap_Terminal · APK 工程

把之前那套 KernelSU 模块 WebUI **原样搬进一个独立 App**：装完点开就是界面，不用进 KSU 管理器找模块卡片。

## 它能做什么

- 同一套 WebUI：`.sh` / `.rc` 扫描、内容预览、卡密输入、记住卡密 + 保管口令、清除全部二次确认、init.rc 转译预览、终端回显，界面与模块版完全一致（assets 里就是那三个文件）
- **root 执行**：注入 `window.ksu`，`exec` 在后台线程走 `su -c`，回调形状与 KernelSU 官方接口一致；不依赖管理器
- **清后台不中断**：启动时把 `runner.sh` / `watchdog.sh` 铺到 `/data/local/tmp/DianXia_Swap_Terminal/`，用 `setsid` 拉起 root 侧守护。脚本父进程是 init/ksud，不在 App 进程树里；划掉最近任务、强制停止 App 都不影响；重开续看输出
- **开机自启**：`BOOT_COMPLETED` 广播重新铺守护
- 全离线：不申请 `INTERNET`，无第三方 SDK、无广告、无统计、无 CDN

## 怎么编译出 APK

三种方式，按你手头有什么选。**产物都是同一个文件**：`app/build/outputs/apk/debug/app-debug.apk`

### 方式 A：Android Studio（最省事，推荐）

1. 装 [Android Studio](https://developer.android.com/studio)（Hedgehog / Iguana 及以上，自带 JDK 17）
2. 首次启动让它装好 **Android SDK Platform 34**（SDK Manager → SDK Platforms → 勾 Android 14 / API 34）
3. `File > Open` 选中本目录 → 等 Gradle Sync 跑完（首次要下 AGP 8.2.2 / Kotlin 1.9.22 / Gradle 8.2，约 3~10 分钟）
4. 菜单 `Build > Build Bundle(s) / APK(s) > Build APK(s)`
5. 右下角点 `locate` 就能找到 APK

> 工程里已配好阿里云镜像（google / public / gradle-plugin），国内 Sync 不会卡在下载；镜像缺东西会自动回退官方源。

### 方式 B：命令行（不想装 Studio）

```bash
# 前置：JDK 17（java -version 显示 17）、Android SDK（ANDROID_HOME 或 ~/Android/Sdk）
chmod +x build.sh
./build.sh
```

`build.sh` 会自动下载 Gradle 8.2（腾讯镜像 → 官方源双通道）、执行 `assembleDebug`、最后打印 APK 路径。也可以自己跑：

```bash
gradle -p . assembleDebug --no-daemon
```

装到手机：`adb install -r app/build/outputs/apk/debug/app-debug.apk`，或者把文件传到手机点开安装。

### 方式 C：GitHub Actions 云编译（**只有手机也能做**）

工程里已经放好 `.github/workflows/build.yml`，不用电脑：

1. 解压工程 zip，新建 GitHub 仓库，把**里面的文件都上传**（注意 `.github` 是隐藏目录，网页上传时容易被漏掉；可以用仓库页面的 `Add file > Upload files`，或把整个目录拖进去）
2. 仓库页 → **Actions** → 左侧 `构建 APK` → **Run workflow** → 再点一次 Run
3. 等约 5~10 分钟，刷新页面，底部 **Artifacts** 里下载 `DianXia_Swap_Terminal-debug`（zip 包），解压出 `app-debug.apk`
4. 传到手机安装

云端 workflow 会自动装 JDK 17、Android SDK 34、Gradle 8.2，并把 `settings.gradle` 里的国内镜像去掉改用官方源，不需要你配任何东西。

### 环境要求速查

| 项 | 要求 |
|---|---|
| JDK | **17**（AGP 8.2 强制；Java 8 / 11 会直接报版本错） |
| Android SDK | Platform **34** + Build Tools 34 |
| Gradle | 8.2（脚本自动下载） |
| 网络 | 首次需下载依赖，之后可离线 |
| 签名 | debug 签名，可直接安装自测；上架需自己配 `signingConfig` |

### 常见报错

- **`Android Gradle plugin requires Java 17`** → 装 JDK 17，Studio 里 `Settings > Build Tools > Gradle > Gradle JDK` 选 17，或在 `gradle.properties` 加 `org.gradle.java.home=/路径/到/jdk17`
- **`SDK location not found`** → 建 `local.properties` 写 `sdk.dir=/你的/Android/Sdk`，或设环境变量 `ANDROID_HOME`
- **Sync 一直转圈 / 下载超时** → 已配阿里云镜像，若仍失败检查代理；也可临时删掉 `settings.gradle` 里的 `maven.aliyun.com` 三行走官方源
- **`Could not resolve com.android.tools.build:gradle:8.2.2`** → 确认 JDK 17 + 网络，清缓存重来：`rm -rf ~/.gradle/caches && ./build.sh`
- **`Execution failed for task :app:processDebugResources` / aapt 报错** → 确认装了 Build Tools 34：`sdkmanager "build-tools;34.0.0"`

> 当前交付的是**完整源码工程，不是已编译的 `.apk`**：生成它的环境没有 Android SDK / Java 编译器，也没有实机编译验证。Kotlin 侧是首次编写，如遇编译报错按上面清单或 Studio 提示微调即可（多数是 Gradle / AGP 版本匹配问题）。WebUI 部分与模块版共用同一套代码，已跑过完整回归。

## 装到手机后

1. 设备需要 **已 root**（KernelSU / Magisk / APatch 均可），首次打开会在 `su` 时弹授权，**选永久允许**
2. 打开 App → 终端面板状态条显示「系统守护在线」即可跑脚本；显示红色就点「拉起守护」
3. 建议把管理器/本 App 加入电池优化白名单，避免部分 ROM 冻结后台（守护本身在 root 侧，一般不受影响）
4. 刷完不需要重启；重启后 `BootReceiver` 会自动拉起守护

**默认脚本目录**：`/data/local/tmp/DianXia_Swap_Terminal/scripts`（App 启动时自动创建；目录为空时会自动放入 5 个内置示例，包括卡密演示与 `.rc` 转译演示，之后不再覆盖你放进来的文件）。也可以点界面里的路径快捷入口切到 `/sdcard/Download/scripts` 等，或从文件选择器「导入」。

## 与模块版的关系（重要）

| | 模块版（zip） | APK 版 |
|---|---|---|
| 入口 | KSU 管理器 → 模块卡片 → WebUI | 桌面图标直接打开 |
| 执行通道 | 管理器注入的 `kernelsu` / `ksu` | App 自己注入 `window.ksu` → `su -c` |
| 守护目录 | `/data/local/tmp/DianXia_Swap_Terminal` | **同一个目录** |
| 卡密库 | 管理器 WebView 的 localStorage | APK WebView 的 localStorage |

- **两者共用同一套 root 守护**，同时装不会起两个守护；但**卡密库是各自独立的**——WebView 的 localStorage 按应用隔离，模块版里记住的卡密不会自动出现在 APK 版里，需要重新勾一次「记住这份卡密」。
- 脚本目录彼此独立（模块版在 `/data/adb/modules/...`，APK 版在 `/data/local/tmp/...`），界面里可以手动切到对方目录，共用同一批 `.sh` / `.rc`。
- 只想要一个的话，装 APK 就够了，模块可以卸载。

## 已知边界（如实说明）

- **本工程在当前构建环境里没有实机编译验证**：生成它的沙盒没有 Android SDK、没有 Java 编译器，SDK 下载被网络策略拦截，所以这里只能交付完整源码工程，无法产出可直接安装的 `.apk` 二进制。逻辑与模块版共用同一套 WebUI（那部分已跑过完整回归），Kotlin 侧是首次编写，如有编译报错按 Android Studio 提示微调即可（通常是 Gradle/AGP 版本匹配）。
- `spawn` 实时 stdin 交互依赖管理器 ESM 接口，APK 版没有该接口 → 自动走「预填注入」通道（`stdin` + `$1..` + 环境变量三种同时给），功能不受影响；「跟随界面」模式的实时输入条不会出现。
- 依赖 `setsid`、`nohup`、`base64`、`su` 这些 Toybox/BusyBox 工具，主流 Android 8+ 都有；个别精简 ROM 缺 `setsid` 时会回退成随 App 生命周期执行。
- 和模块版一样：卡密保存在本机 WebView 存储里，**不是保险箱**，设备已 root，公用设备请勿保存敏感卡密。个别定制 WebView 若禁用 `file://` 的 localStorage，卡密库会提示「当前环境不支持本地存储」，其余功能不受影响。
- `minSdk 26`（Android 8.0），`targetSdk 34`，零外部依赖。

## 目录

```
DianXia_Swap_Terminal_apk/
├── settings.gradle / build.gradle / gradle.properties
├── build.sh                      # 命令行一键构建
├── .github/workflows/build.yml   # GitHub Actions 云编译（只有手机也能出 APK）
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/dianxia/swapterminal/
│       │   ├── MainActivity.kt   # WebView + 文件选择器 + su 桥注入
│       │   ├── KsuJsApi.kt       # window.ksu.exec / toast，后台线程 + JS 回调
│       │   ├── RootExec.kt       # su -c 封装、守护脚本铺设、setsid 拉起
│       │   └── BootReceiver.kt   # 开机重建守护
│       ├── assets/
│       │   ├── webroot/          # index.html / app.js / style.css（路径已适配 APK）
│       │   └── scripts/          # runner.sh / watchdog.sh
│       └── res/                  # 图标、主题、字符串
```

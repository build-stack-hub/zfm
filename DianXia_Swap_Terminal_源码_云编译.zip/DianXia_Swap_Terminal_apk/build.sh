#!/usr/bin/env bash
# 命令行一键构建：自动准备 Gradle 8.2 → assembleDebug
# 要求：JDK 17（AGP 8.2 强制要求）+ 网络（下载 Gradle / AGP / Android SDK 依赖）
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
GV="8.2"
CACHE="${GRADLE_USER_HOME:-$HOME/.gradle}/dxst-gradle-$GV"
GRADLE_BIN="$CACHE/gradle-$GV/bin/gradle"

if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then
    export PATH="$JAVA_HOME/bin:$PATH"
fi

echo "==> 检查 Java 版本（需要 17）"
if command -v java >/dev/null 2>&1; then
    java -version 2>&1 | head -n 2
else
    echo "❌ 没找到 java，请先安装 JDK 17 并配置 JAVA_HOME"; exit 1
fi

if command -v gradle >/dev/null 2>&1; then
    GRADLE="$(command -v gradle)"
    echo "==> 使用系统 Gradle: $GRADLE"
elif [ -x "$GRADLE_BIN" ]; then
    GRADLE="$GRADLE_BIN"
else
    echo "==> 下载 Gradle $GV ..."
    mkdir -p "$CACHE"
    ZIP="$CACHE/gradle-$GV-bin.zip"
    URLS=(
        "https://mirrors.cloud.tencent.com/gradle/gradle-$GV-bin.zip"
        "https://services.gradle.org/distributions/gradle-$GV-bin.zip"
    )
    ok=0
    for u in "${URLS[@]}"; do
        echo "    尝试: $u"
        if command -v curl >/dev/null 2>&1; then
            curl -fL --retry 2 --connect-timeout 15 -o "$ZIP" "$u" && ok=1 && break
        else
            wget -q -O "$ZIP" "$u" && ok=1 && break
        fi
    done
    [ "$ok" -eq 1 ] || { echo "❌ Gradle 下载失败，请手动下载 gradle-$GV-bin.zip 解压到 $CACHE"; exit 1; }
    (cd "$CACHE" && unzip -q -o "$ZIP")
    GRADLE="$GRADLE_BIN"
fi

echo "==> 开始构建 debug APK（首次约 3~10 分钟）"
"$GRADLE" -p "$DIR" assembleDebug --no-daemon --stacktrace

APK="$DIR/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    echo ""
    echo "✅ 构建成功: $APK"
    echo "   安装: adb install -r \"$APK\""
    echo "   或把这个文件传到手机，用文件管理器点开安装。"
else
    echo "❌ 没找到产物，看上面的报错（常见：Android SDK 未安装 / JDK 版本不对 / 网络下载失败）"
    exit 1
fi
